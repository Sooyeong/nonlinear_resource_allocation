function [x,status] = ra_peg_lincon(Ifree,lincon,rhs,lo,up,pegSolve,timeout)
% Resource allocation via pegging method.
%
% SUMMARY:
%   x = ra_peg(Ifree,lincon,rhs,lo,up,pegSolve) minimizes
%       sum(obs(x)) over all x with lo <= x <= up, sum(lincon.*x) == rhs.
%
% The function obs is not passed as an input because it is implemented
% implicitly in the input function pegSolve(I,new_rhs), which solves
% subproblems of the form: 
%       min sum(obj(x(I),I)) s.t. sum(lincon(I).*x(I)) == new_rhs
% 
% The vector Ifree indicates which subvector of x should be used, so that
% the problem is interpreted instead as minimizing sum(obj(x(Ifree),Ifree))
% over x with lo <= x(Ifree) <= up, sum(lincon.*x(Ifree))==rhs. Therefore,
% the returned vector is actually x(Ifree).
%
% ASSUMPTIONS:
%   * sum(obj) is convex, separable, twice differentiable
%   * problem is feasible
%   * lo and up are finite with lo < up
%   * pegSolve 
%
% IMPLEMENTATION NOTES:
%   The following code assumes the input data Ifree, lincon, lo, up consist
%   of vectors of the same shape (column).
%
% NOTATION:
%   * x denotes optimal solution to the pegged subproblem at each iteration
%   * I = index set of unpegged variables
%   * U = index set of variables pegged to upper bounds
%   * L = index set of variables pegged to lower bounds
%   * IA = indices in I that do not satisfy upper bounds
%   * IB = indices in I that do not satisfy lower bounds

dim = length(up); % Dimension
status = 0;

if dim==0
    return % nothing to do
end
if islogical(Ifree)
    error('Ifree must be a numeric index vector')
    % perhaps we can get around this with more elaborate coding?
end

% Initialization
I = true(dim,1);
x = zeros(dim,1);
con_up = lincon.*up;
con_lo = lincon.*lo;

% some variables can be pegged because they're fixed by the bounds
IA = lo==up;
I(IA) = false;
x(IA) = lo(IA);
rhs = rhs-sum(con_lo(IA));
dim = nnz(I);

for k = 1:dim
    
    if mod(k,100)&&timeout(), status = 1; return, end
    
    % Solve the subproblem
    [x(I),status] = pegSolve(Ifree(I),rhs,timeout);
    if status
        return
    end
    
    % Identify variables in subproblem solution that don't satisfy bounds
    IA = x > up;
    IB = x < lo;
    
    conA = sum(con_up(IA));
    SA = sum(lincon(IA).*x(IA)) - conA;
    conB = sum(con_lo(IB));
    SB = conB - sum(lincon(IB).*x(IB));
    % Stopping criterion (Kiwiel version)
    if SA == SB
        % ensure final answer is feasible (coincidence Kiwiel that ignored)
        x(IA) = up(IA);
        x(IB) = lo(IB);
        break
    end
    
    % Pegging (Kiwiel version)
    if SB<SA
        % remove IA indices from I and peg their x-values to up
        I(IA) = false;
        x(IA) = up(IA);
        rhs = rhs - conA;
    else
        % remove IB indices from I and peg their x-values to lo
        I(IB) = false;
        x(IB) = lo(IB);
        rhs = rhs - conB;
    end
end

end % function ra_peg
