function [x,status] = ra_breakpt_lincon(...
    obj,Ifree,lincon,rhs,lo,up,subSolve,interSolve,timeout)
% Resource allocation via breakpoint search.
%
% x = ra_breakpt_lincon(obj,Ifree,rhs,lo,up,subSolve,interSolve)
% minimizes sum(obj(x)) over x with lo <= x <= up, sum(lincon.*x) == rhs .
%
% The vector Ifree indicates which subvector of x should be used, so that
% the problem is interpreted instead as minimizing sum(obj(x(Ifree),Ifree))
% over x with lo <= x(Ifree) <= up, sum(lincon.*x(Ifree))==rhs. Therefore,
% the returned vector is actually x(Ifree).
% 
% Assumes:
%   * sum(obj) is separable, convex and twice differentiable
%   * problem is feasible
%   * Ifree is a numeric index vector
%   * lo and up are finite with lo<up
%   * lincon is a vector of positive numbers
%   * the lengths of lo, up and lincon are equal to nnz(Ifree)
%   * [f(I),f1(I),f2(I)] = obj(x,I) returns vector of values for obj and
%     its first and second derivatives (also as vectors)
%     at the coordinates specified by the index vector I
%   * subSolve finds x with f1(x)+rho*lincon==0 for a given rho
%   * interSolve solves for x over rho between consecutive breakpoints

% Note: the following code assumes all data consists of vectors of the
% same shape (row or column).

% Notation used below:
% * rho is the multiplier associated with the linking constraint
% * conxrho is sum(x(rho)), where x(rho) is implicitly defined as
%     as the solution x of f'(x)+rho*lincon=0 modified so that lo<=x<=up
% * brk is the full list of breakpoints of conxrho as a function of rho
% * Rho is list of remaining breakpoints of interest
% * rholo, rhoup are upper and lower bounds on the optimal rho

% Note: assumes sum(x(rho)) is nonincreasing in rho, which will
% always be true by the convexity of f.
n = nnz(Ifree);
x = zeros(n,1);

if n==0
    status = 0;
    return % nothing to do
end
if islogical(Ifree)
    error('Ifree must be a numeric index vector')
    % perhaps we can get around this with more elaborate coding?
end
I = true(n,1);
xfree = zeros(n,1);

% create list of breakpoints
brk = zeros(n,2);
[~,f1] = obj(lo,Ifree(I));
con_lo = lincon.*lo;
brk(:,1) = -f1./lincon;
[~,f1] = obj(up,Ifree(I));
con_up = lincon.*up;
brk(:,2) = -f1./lincon;

rholo = -inf;
rhoup = inf;
Rho = brk(:);

i1 = 1;
i2 = 2*n;

iters = 0;
status = 0;

while i1<=i2 %  Note: 2 other opportunities to BREAK OUT are given below.
    
    iters = iters+1;
    if mod(iters,100)==0&&timeout()
        status = 1;
        return
    end
    
    % select rho from Rho
    m = floor((i1+i2)/2);
    Rho(i1:i2) = kselect_swap(m-i1+1,Rho(i1:i2));
    rho = Rho(m);
    
    % calculate sum(con(x(rho)))
    Jlo = I;
    Jlo(I) = rho>=brk(I,1);
    conlo_rho = sum(con_lo(Jlo));
    Jup = I;
    Jup(I) = rho<=brk(I,2);
    conup_rho = sum(con_up(Jup));
    Jfree = I&~(Jlo|Jup);
    [xfree(Jfree),status] = subSolve(rho,Ifree(Jfree),timeout);
    if status
        return
    end
    conxrho = sum(lincon(Jfree).*xfree(Jfree)) + conlo_rho + conup_rho ...
        - sum(con_up(Jup&Jlo)); % avoid double-counting
   
    % update bracket around optimal rho
    drhs = 0;
    
    if conxrho>=rhs
        rholo = rho;
        drhs = conlo_rho;
        x(Jlo) = lo(Jlo); % these x(i) are fixed for subsequent iterations
        I(Jlo) = false;
        % Rearrange Rho and increase i1 so that Rho(i1:i2)>rho.
        i1 = m+1;
        k = i2;
        while i1<=k
            if Rho(k)==rho
                Rho(k) = Rho(i1); Rho(i1) = rho; i1 = i1+1;
            end
            while Rho(k)>rho, k = k-1; end
        end
    end

    if conxrho<=rhs
        rhoup = rho;
        drhs = drhs + conup_rho;
        x(Jup) = up(Jup); % these x(i) are fixed for subsequent iterations
        I(Jup) = false;
        % Rearrange Rho and decrease i2 so that Rho(i1:i2)<rho.
        k = i1;
        i2 = m-1;
        while k<=i2
            if Rho(k)==rho
                Rho(k) = Rho(i2); Rho(i2) = rho; i2 = i2-1;
            end
            while Rho(k)<rho, k = k+1; end
        end
    end
    
    rhs = rhs - drhs;

end

% calculate final answer
if any(I)
    [x(I),status] = interSolve(rholo,rhoup,Ifree(I),rhs,timeout);
end

end % function ra_breakpt_lincon
