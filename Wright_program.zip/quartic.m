function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    quartic(dim,internal)
% problem data for:
%   obj = convex quartic
%   con = sum (i.e., simplex)

% create coordinate-level data: obj(x) = a*x^4+b*x^3+c*x^2+d*x

% convexity on the real line requires   8*a*c>=3*b^2, a>=0, c>=0  so we
% extract a,b,c from a random PD matrix = A'*A
A = randn(dim,2,2);
a = reshape(A(:,1,1).^2+A(:,2,1).^2,dim,1)/sqrt(8);
b = reshape(A(:,1,1).*A(:,1,2)+A(:,2,1).*A(:,2,2),dim,1)/sqrt(3);
c = reshape(A(:,1,2).^2+A(:,2,2).^2,dim,1)/sqrt(8);
% choose d so the critical point of obj is positive
d = zeros(dim,1);
critpt = 10*rand(dim,1);
[~,d] = objective(critpt,true(dim,1));
d = -d;
up = 2*critpt.*rand(dim,1); % 0 < up <= 2*critpt, to vary monotonicity
lo = up.*rand(dim,1); % 0 < lo < up
% choose rhs last to guarantee feasibility
arhs = cumsum(lo + (up-lo).*rand(dim,1));

% function handles
obj = @objective;
lincon = ones(size(up)); % standard simplex constraint
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

% values pre-calculated for subproblem solvers
a4 = 4*a;
eta = -b./a4;
[~,sigma,zeta] = objective(eta);
zeta = zeta./a4;
sigma = sigma./a4;
tau = lincon./a4;

% no closed-form solvers, but a special numerical subSolve is available
if nargin<2||internal
    subSolve = @subSolveRoutine;
    interSolve = @interSolverRoutine;
    pegSolve = setpegSolver_lincon(obj,lincon,dom);
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end
iters = 0;

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        f = (((a(index).*x+b(index)).*x+c(index)).*x+d(index)).*x;
        if nargout>1
            f1 = ((4*a(index).*x+3*b(index)).*x+2*c(index)).*x+d(index);
            if nargout>2
                f2 = (12*a(index).*x+6*b(index)).*x+2*c(index);
            end
        end
    end

    function [xh,status] = subSolveRoutine(lambda,I,timeout)
        % solve cubic equation f1(x)+lambda*lincon=0 for x by applying NM
        % to z^3+zeta*z+(sigma+tau*lambda)=0 and recovering x=z+eta
        z = zeros(size(a));
        res = zeros(size(a));
        tol = zeros(size(a));
        dz = zeros(size(a));
        stl = zeros(size(a));
        
        stl(I) = sigma(I)+tau(I)*lambda;
        % initial guess: z=-stl^(1/3) for monotonic convergence to root
        z(I) = -sign(stl(I)).*abs(stl(I).^(1/3)); % need real roots
        tol(I) = 1e-10*(1+abs(zeta(I))+abs(stl(I)));
        J = false(size(a));
        J(I) = true;
        J(J) = abs(zeta(J))>1e-12; % problem already solved if zeta==0
        status = 0;
        while any(J)
            iters = iters+1;
            if mod(iters,100)==0&&timeout()
                status=1; xh = z(I)-eta(I); return
            end
            res(J) = z(J).*(z(J).^2+zeta(J))+stl(J);
            dz(J) = -res(J)./(3*z(J).^2+zeta(J));
            J(J) = abs(dz(J))>=1e-10*z(J) & abs(res(J))>=tol(J).*abs(z(J));
            z(J) = z(J)+dz(J);
        end
        xh = z(I)-eta(I);
    end

    function [x,status] = interSolverRoutine(rho_lo,rho_up,M,rhs,timeout)
        % Find x that corresponds to rho having
        %     rhs==sum(lincon(M).*subSolve(rho,M)),   rho_lo<rho<rho_up.
        % Approach: apply Newton's method with bisection failsafe.
        status =0;
        if length(M)==1
            % solution in closed form
            x = rhs/lincon(M);
            % quick check on correctness
            [~,f1] = objective(x,M);
            rho = -f1/lincon(M);
            if rho>rho_up || rho<rho_lo
                status = 1;
            end
            return
        end
        tol = 1e-11;
        
        [x,status] = subSolveRoutine(rho_lo,M,timeout);
        if status, return, end
        reslo = sum(lincon(M).*x)-rhs;
        if reslo==0, return, end
        [x,status] = subSolveRoutine(rho_up,M,timeout);
        if status, return, end
        resup = sum(lincon(M).*x)-rhs;
        if resup==0, return, end

        rho = (rho_lo+rho_up)/2;
        if sign(reslo)==sign(resup)
            if abs(rho_lo-rho_up)>tol/100
                status = 1;
            end
            return
        end
        [x,status] = subSolveRoutine(rho,M,timeout);
        if status, return, end
        res = sum(lincon(M).*x)-rhs;
            % apply Newton step

        drho = inf; % no Newton step yet
        while res~=0 ... % not exact root
                && rho_up-rho_lo>tol*max(abs(rho_lo),abs(rho_up))... % wide bracket
                && abs(drho)>tol*abs(rho) % large Newton step
            iters = iters+1;
            if mod(iters,100)==0&&timeout(), status=1; break, end
            dx = -tau(M)./(3*(x+eta(M)).^2+zeta(M));
            dres = sum(lincon(M).*dx);
            drho = res/dres; % Newton step
            rho = rho - drho;
            
            if rho>rho_up || rho<rho_lo % Newton step escapes bracket
                drho = inf; % discard Newton step
                rho = (rho_lo+rho_up)/2; % bisect interval as failsafe
            end
            [x,status] = subSolveRoutine(rho,M,timeout);
            if status, return, end
            res = sum(lincon(M).*x)-rhs;
            
            % tighten bracket
            if sign(reslo)==sign(res)
                rho_lo = rho; reslo = res;
            elseif sign(resup)==sign(res)
                rho_up = rho; resup = res;
            end

        end
    end

end % quartic

