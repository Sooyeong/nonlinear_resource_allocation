function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    melman(dim,internal)
% problem data for Melman-Rabinowitz (they used dim=500:500:3000)

a = .001+(1000-.001)*rand(dim,1);
b = .001+(1000-.001)*rand(dim,1);
adivb = a./b;
inva = 1./a;
bdiva = b.*inva;
gamma = min(adivb); % upper bound for multiplier rho
xx = zeros(dim,1);
iters = 0;
xx(adivb>gamma) = subSolverRoutine(gamma,adivb>gamma,@(t)false);
K = sum(b.*xx); % infimum for rhs guaranteeing optimal 0<rho<gamma
rhs = 1.1*K; % raise K above its minimum poosible (M&R used 1.001*K)
  % [peg and breakpoint can't handle 1.01 or smaller, but
  %  ipm seems to have no trouble]
lo = zeros(dim,1); % formally excluded, but f has been extended
up = rhs./b; % formally infinite, but this very large bound is implied
  % [guarantees that g(lo)=0 <rhs< dim*rhs=g(up)]
arhs = cumsum(lo+b.*(up-lo).*rand(dim,1));

% function handles
obj = @objective;
lincon = b;
dom = struct(...
    'lo',zeros(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',false(dim,1),...
    'up_excl',true(dim,1));

% no closed-form solvers, but special subSolve available
if nargin<2||internal
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
%    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
%        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = @pegSolverRoutine;
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end
iters = 0;

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        I = x>0;
        invx = 1./x(I);
        eninvx = exp(-invx);
        f = -x; % important for x=0 (numerically helpful for x<0)
        f(I) = x(I).*(eninvx-1);
        f = f.*a(index);
        if nargout > 1
            f1 = -ones(size(x));
            f1(I) = (1+invx).*eninvx-1;
            f1 = f1.*a(index);
            if nargout>2
                f2 = zeros(size(x));
                f2(I) = eninvx .* invx.^3;
                f2 = f2.*a(index);
            end
        end
    end

    function [x,status] = subSolverRoutine(rho,I,timeout)
        % Minimize obj(x,I)+rho*con(x,I) over x in the domain.
        
        % First preallocate working space
        J = false(size(a));
        J(I) = true;
        q = zeros(size(a));
        y = zeros(size(a));
        invx = zeros(size(a));
        einvx = zeros(size(a));
        dx = zeros(size(a));
        xtmp = zeros(size(a)); 
        
        % Need to solve (1+1/x)*exp(-1/x)-q==0 for x>0.
        y(J) = rho.*bdiva(J); % expect 0<y<=1
        q(J) = 1-y(J); % expect 0<=q<1

        % special case: q near 0 gives x=0 (i.e., preallocated value of x)
        J(J) = q(J)>eps; % continue processing these coordinates
        
        % special case: q near 1 uses perturbation-analysis approximation
        JJ = J;
        JJ(JJ) = y(JJ)<1e-8; % q near 1
        a1 = sqrt(2); a2 = 2/3; a3 = 11*a1/36; %a3 = (11-12*a1)/18;
        xtmp(JJ) = 1./((a1+a3*y(JJ)).*sqrt(y(JJ))+a2*y(JJ));
        J(J&~JJ) = true; % continue processing these coordinates
        
        % Apply Newton's method to general case, starting at inflection.
        xtmp(J) = 1/3;
        status = 0;
        while any(J)
            iters = iters+1;
            if mod(iters,100)==0&&timeout(), status=1; x=xtmp(I); return, end
            invx(J) = 1./xtmp(J);
            einvx(J) = exp(invx(J));
            dx(J) = (1+invx(J)-q(J).*einvx(J)) .* xtmp(J).^3;
            % keep only those indices where xx hasn't converged yet
            J(J) = abs(dx(J))>=1e-11*xtmp(J) & ...
               abs(q(J)-(1+invx(J))./einvx(J))>=1e-11*q(J);
            xtmp(J) = xtmp(J)-dx(J);
        end
        x = xtmp(I);
    end

    function [x,status] = interSolverRoutine(rho_lo,rho_up,M,rhs,timeout)
        % Find the x that corresponds to rho having
        %     rhs==sum(b(M).*subSolve(rho,M)),   rho_lo<rho<rho_up.
        % Approach: multiply equation by 1-b(k)*rho, then apply Newton's
        % method initialized at the left endpoint rho_lo.

        status =0;
        if length(M)==1
            % solution in closed form
            x = rhs/b(M);
            [~,f1] = objective(x,M);
            rho = -f1/b(M);
            if rho>rho_up || rho<rho_lo
                status = 1;
            end
            return
        end
        
        bk = max(bdiva(M));
        rho = rho_lo;
        [x,status] = subSolverRoutine(rho,M,timeout);
        if status, return, end
        bx = b(M).*x;
        sumbx = sum(bx);
        res = (1-bk*rho)*(sumbx-rhs);

        drho = inf; % no Newton step yet
        while res~=0 ... % did not find root exactly
                && abs(drho)>1e-10*abs(rho) % Newton step is large
            iters = iters+1;
            if mod(iters,100)==0&&timeout(), status=1; break, end
            
            dres = -bk*sumbx -(1-bk*rho)*sum(bx.*x.^2.*bdiva(M).*exp(1./x));
            drho = res/dres; % Newton step
            rho = rho - drho;
            
            %if res~=0 && abs(drho)>1e-10*abs(rho) && (rho>rho_up || rho<rho_lo)
            %%%% THIS CONDITION ONLY MET FOR VERY SMALL DISCREPANCIES
            %    disp('bad NM step')
            %end
            [x,status] = subSolverRoutine(rho,M,timeout);
            if status, break, end
            bx = b(M).*x;
            sumbx = sum(bx);
            res = (1-bk*rho)*(sumbx-rhs);
        end
    end

    function [x,status] = pegSolverRoutine(M,rhs,timeout)
        % starting guess from Melman & Rabinowitz
        rho = min(adivb(M))*sum(b(M).*subSolverRoutine(rhs/sum(b(M))));
        [x,status] = interSolverRoutine(rho,[],M,rhs,timeout);
    end


end % melman
