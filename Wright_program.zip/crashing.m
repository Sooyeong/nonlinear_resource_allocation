function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    crashing(dim,internal)
% Crashing instance

p=exprnd(1,dim,1);
root_p = sqrt(p);
%Lower bound and upper bound for the domains
%d-> upper bound
up=exprnd(1,dim,1);
%alpha->exp(0.75)
alpha=exprnd(0.75,dim,1);
%c-> Lower bound
lo=min(.9*alpha,up/2);
%rhs-> sum of x's
arhs=cumsum(alpha);
% function handles
obj=@objective;
lincon=ones(size(up));
dom = struct(...
    'lo',zeros(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

if nargin<2||internal
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
    pegSolve = @pegSolverRoutine;
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end


% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        f =p(index)./x;
        if nargout > 1
            f1 = -f./x;
            if nargout > 2
                f2 = -2*f1./x;
            end
        end
    end % objective function

    function [x,status]=subSolverRoutine(lambda,I,~)
        % minimize sum(obj(x,I)+lambda*con(x,I)) over x
        x = root_p(I)/sqrt(lambda);
        status = 0;
    end

    function [x,status] = pegSolverRoutine(I,rhsI,~)
        % minimize sum(obj(x,I)) s.t. sum(con(x,I))==rhsI
        lambda = (sum(root_p(I))/rhsI)^2;
        x = subSolverRoutine(lambda,I);
        status = 0;
    end

    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,I,rhsI,~)
        lambda = (sum(root_p(I))/rhsI)^2;
        lambda = max(lambda_lo,min(lambda,lambda_up));
        x = subSolverRoutine(lambda,I);
        status = 0;
    end

end