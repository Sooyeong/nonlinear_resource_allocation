function [x,status] = ra_nested_vjm3(...
    obj,aindex,arhs,eqrhs,weight,lo,up,subSolve,interSolve,timeout)
% this version of ra_nested_vjm avoids recursive function calls, which
% makes it faster when m is close to n

% append final constraints to rest; provide start indices for ranges
arhs_m1 = [0;arhs(:)];
arhs = [arhs(:);eqrhs];
ai_m1 = [0;aindex(:)];
aindex = [aindex(:);size(lo,1)];

% initialize decision variables
x = zeros(size(lo));
lo_sub = lo;
up_sub = up;

% use a stack to traverse the binary tree
D = 1+ceil(log2(length(aindex))); % maximum depth
v = zeros(D,1);
w = zeros(D,1);
t = zeros(D,1);
left = true(D,1);
done = false(D,1);

% push root node onto stack
depth = 1;
v(1) = 1;
w(1) = length(aindex);

while depth>0
    if v(depth)==w(depth) || done(depth) % Solve
        Start = ai_m1(v(depth))+1;
        Finish = aindex(w(depth));
        if v(depth)==w(depth)
            up_sub(Start:Finish) = up(Start:Finish);
            lo_sub(Start:Finish) = lo(Start:Finish);
        else
            Middle = aindex(t(depth));
            up_sub(Middle+1:Finish) = up(Middle+1:Finish);
            lo_sub(Middle+1:Finish) = x(Middle+1:Finish);
            up_sub(Start:Middle) = x(Start:Middle);
            lo_sub(Start:Middle) = lo(Start:Middle);
        end
        [x(Start:Finish),status] = ra_breakpt_lincon(...
            obj,Start:Finish,weight(Start:Finish),...
            arhs(w(depth))-arhs_m1(v(depth)),...
            lo_sub(Start:Finish),up_sub(Start:Finish),...
            subSolve,interSolve,timeout);
        if status, return, end
        done(depth) = false;
        depth = depth-1; % pop
    
    elseif left(depth) % Branch Left
        t(depth) = floor((v(depth)+w(depth))/2);
        v(depth+1) = v(depth);
        w(depth+1) = t(depth);
        left(depth) = false;
        depth = depth+1; % push
    
    else % Branch Right
        v(depth+1) = t(depth)+1;
        w(depth+1) = w(depth);
        left(depth) = true;
        done(depth) = true;
        depth = depth+1; % push
    end
end

end