function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    everett(dim,internal)
% problem data for Everett (OR, 1960)

% create coordinate-level data
r = rand(dim,1); % 0<q<1
logr = log(r);
b = 1+9*rand(dim,1); % 1<a<10
lo = rand(dim,1); % 0<lo<1
up = lo+(10-lo).*rand(dim,1); % lo<up<10
% choose arhs last to guarantee feasibility
arhs = cumsum(b.*lo+b.*(up-lo).*rand(dim,1));

% function handles
obj = @objective;
lincon = b;
dom = struct(...
    'lo',zeros(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

% closed-form subSolve, but none for pegSolve or interSolve
if nargin<2||internal
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
    %interSolve = setinterSolver_lincon(@objective,lincon,dom,...
    %    @subSolverRoutine);
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        rx = r(index).^x;
        f = -log(1-rx);
        if nargout > 1
            ratio = logr(index)./(1-rx);
            f1 = rx.*ratio;
            if nargout>2
                f2 = rx.*ratio.*ratio;
            end
        end
    end

    function [xh,status] = subSolverRoutine(lambda,I,~)
        xh = -log(1-(logr(I)./b(I))/lambda)./logr(I);
        status = 0;
    end

    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,M,rhs,timeout)
        R = -log(r(M))./b(M);
        lambda = lambda_lo;
        undone = true;
        iters = 0;
        while undone 
            iters = iters+1;
            if mod(iters,100)==0&&timeout()
                status=2;
                return
            end
            phi = rhs - sum(log(1+R/lambda)./R); % need this == 0
            dphi = sum(1./(lambda+R))/lambda;
            dlambda = phi/dphi;
            lambda = lambda - dlambda;
            undone = abs(dlambda)>=1e-10*lambda & abs(phi)>=1e-10;
        end
        x = subSolverRoutine(lambda,M);
        status = 0;
    end

end % everett

