%% y=g(x) and approx ginv(y)=x on short linear axes
a1 = sqrt(2); a2 = 2/3; a3 = (11-12*a1)/18;
g = @(x)1-(1+1./x).*exp(-1./x);
ginv = @(y)1./((a1+a3*y).*sqrt(y)+a2*y);

x = 1e8*linspace(.1,1,5000);
y = linspace(min(g(x)),max(g(x)),5000);

close all
plot(x,g(x),'r')
hold on
plot(ginv(y),y,'k')
title('red: $x\mapsto y=g(x)$\qquad black: $x=\widetilde{g^{-1}}(y)\mapsto y$',...
    'Interpreter','latex')
xlabel('$x$','Interpreter','latex'),ylabel('$y$','Interpreter','latex')
axis([1e7 1e8 0 5e-15])

%% y=g(x) and approx ginv(y)=x on long LogLog axes
a1 = sqrt(2); a2 = 2/3; a3 = (11-12*a1)/18;
g = @(x)1-(1+1./x).*exp(-1./x);
ginv = @(y)1./((a1+a3*y).*sqrt(y)+a2*y);

x = logspace(-1,10,5000);
y = logspace(-16,1,5000);

close all
loglog(x,g(x),'r')
hold on
loglog(ginv(y),y,'k')
axis([5e-2 1e10 1e-17 5e1])
title('red: $x\mapsto y=g(x)$\qquad black: $x=\widetilde{g^{-1}}(y)\mapsto y$',...
    'Interpreter','latex')
xlabel('$x$','Interpreter','latex'),ylabel('$y$','Interpreter','latex')

%% x vs approximate ginv(g(x)) and y vs g(ginv(y)) on long LogLog axes
a1 = sqrt(2); a2 = 2/3; a3 = (11-12*a1)/18;
g = @(x)1-(1+1./x).*exp(-1./x);
ginv = @(y)1./((a1+a3*y).*sqrt(y)+a2*y);

x = logspace(-2,10,5000);
y = logspace(-15,-1,5000);

close all
subplot(1,2,1)
loglog(x,ginv(g(x)),'r'), axis([1e-2 1e10 1e-2 1e10]), axis square
title('$x\mapsto\widetilde{g^{-1}}(g(x))$','Interpreter','latex')
xlabel('$x$','Interpreter','latex')

subplot(1,2,2)
loglog(y,g(ginv(y)),'k'), axis([1e-16 1e0 1e-16 1e0]), axis square
title('$y\mapsto g(\widetilde{g^{-1}}(y))$','Interpreter','latex')
xlabel('$y$','Interpreter','latex')

%% y=h(t) and approx hinv(y)=t on short linear axes
a1 = sqrt(2); a2 = 2/3; a3 = (11-12*a1)/18;
h = @(t)1-(1+t).*exp(-t);
hinv = @(y)((a1+a3*y).*sqrt(y)+a2*y);

t = 1e-7*linspace(.1,1,5000);
y = linspace(min(h(t)),max(h(t)),5000);

close all
plot(t,h(t),'r')
hold on
plot(hinv(y),y,'k')
title('red: $t\mapsto y=h(t)$\qquad black: $t=\widetilde{h^{-1}}(y)\mapsto y$',...
    'Interpreter','latex')
xlabel('$t$','Interpreter','latex'),ylabel('$y$','Interpreter','latex')

%% y=h(t) and approx hinv(y)=t on long LogLog axes
a1 = sqrt(2); a2 = 2/3; a3 = (11-12*a1)/18;
h = @(t)1-(1+t).*exp(-t);
hinv = @(y)((a1+a3*y).*sqrt(y)+a2*y);

t = logspace(-8,2,5000);
y = logspace(-16,1,5000);

close all
loglog(t,h(t),'r')
hold on
loglog(hinv(y),y,'k')
axis([5e-9 5e2 1e-17 5e1])
title('red: $t\mapsto y=h(t)$\qquad black: $t=\widetilde{h^{-1}}(y)\mapsto y$',...
    'Interpreter','latex')
xlabel('$t$','Interpreter','latex'),ylabel('$y$','Interpreter','latex')

%% t vs approx hinv(h(t)) and y vs h(hinv(y)) on long LogLog axes
a1 = sqrt(2); a2 = 2/3; a3 = (11-12*a1)/18;
h = @(t)1-(1+t).*exp(-t);
hinv = @(y)((a1+a3*y).*sqrt(y)+a2*y);

t = logspace(-10,-2,5000);
y = logspace(-15,-1,5000);

close all
subplot(1,2,1)
loglog(t,hinv(h(t)),'r'), axis([1e-10 1e-2 1e-10 1e-2]), axis square
title('$t\mapsto\widetilde{h^{-1}}(h(t))$','Interpreter','latex')
xlabel('$t$','Interpreter','latex')

subplot(1,2,2)
loglog(y,h(hinv(y)),'k'), axis([1e-16 1e0 1e-16 1e0]), axis square
title('$y\mapsto h(\widetilde{h^{-1}}(y))$','Interpreter','latex')
xlabel('$y$','Interpreter','latex')
