function test_instances

% list of problems:
problems = {
    @bitranm %1
    @churchman %2
    @everett %3
    @logexp %4
    @mcp %5
    @melman %6
    @(d,i)projpball(d,2,2,i) %7
    @(d,i)projpball(d,2.5,2.5,i) %8
    @(d,i)projpball(d,3,3,i) %9
    @(d,i)projpball(d,4,4,i) %10
    @(d,i)projpball(d,2,2.5,i) %11
    @(d,i)projpball(d,2,3,i) %12
    @(d,i)projpball(d,2,4,i) %13
    @(d,i)projpball(d,2.5,2,i) %14
    @(d,i)projpball(d,2.5,3,i) %15
    @(d,i)projpball(d,2.5,4,i) %16
    @(d,i)projpball(d,3,2,i) %17
    @(d,i)projpball(d,3,2.5,i) %18
    @(d,i)projpball(d,3,4,i) %19
    @(d,i)projpball(d,4,2,i) %20
    @(d,i)projpball(d,4,2.5,i) %21
    @(d,i)projpball(d,4,3,i) %22
    @projranball %23
    @projransimp %24
    @(d,i)projsimplex(d,2,i) %25
    @(d,i)projsimplex(d,2.5,i) %26
    @(d,i)projsimplex(d,3,i) %27
    @(d,i)projsimplex(d,4,i) %28
    @qknapsack %29
    @quartic %30
    @strat %31
    };

% list of solvers
methods = struct(...
    'name',{'pegging','breakpoint','IPM','lincon'}', ...
    'solver',{
    @(d,t) ra_peg(d{[1:6,9]},t) %1
    @(d,t) ra_breakpt(d{1:8},t) %2
    @(d,t) ra_ipm(d{[1,2,3,5,6]},t) %3
    @(d,t) ra_breakpt_lincon(...
        d{1},...
        true(size(d{5})),...
        d{2}(ones(size(d{5})))-d{2}(zeros(size(d{5}))),...
        d{[3,5:8]},t) %4
    });

list = [24,26,30]; %1:31;

dim = 1000;
maxtime = 10; % seconds
n_instances = 100;
n_reps = 1;
solvers = [2,3];
internal = true;
prt = false;


for p=1:length(list)
    
    fprintf('%32s : ',func2str(problems{list(p)}));
    [timing,status,objval] = test_ra_solvers(...
        problems{list(p)},dim,maxtime,...
        n_instances,n_reps,...
        methods(solvers),internal,prt);
    fails = sum(status(:));
    fprintf('%11.4f   %11.4f   %3d\n',mean(timing(:)),max(timing(:)),fails);

end

%df = diff(objval,1,2)./max(objval,[],2)

end
