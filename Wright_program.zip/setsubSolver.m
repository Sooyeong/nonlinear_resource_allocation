function subSolve=setsubSolver(obj,con,xlo,xup)
% Creates a solver routine subSolve for the one-dimensional subproblem:
%      "Given rho and i, find x such that f1(x)+rho*g1(x)=0,"
% where [f,f1,f2]=obj(x,i) and [g,g1,g2]=con(x,i).  The solver will be
% callable for a scalar rho as  x = subSolve(rho,I)  to return a vector x
% with one entry for each i in I.  The index array I can be numerical or
% logical.  The returned value in x(i) will be the left (respectively,
% right) endpoint of the domain if the value of f1(x)+rho*g1(x) is
% always above (respectively, below) zero.
%
% Interpretation: f1 is derivative of f, and f2 is derivative of f1.
% Likewise for g,g1,g2.  The values of f and g aren't needed.
%
% The input arguments xlo,xup give an initial bracket for each x-value.:
%
% Assumptions:
%   1. obj1+rho*con1 is nondecreasing for all i and rho;
%   2. xlo <= xup for all i (and values are finite).

% Note: Code that calls subSolve would generally run faster if the tasks
% performed by subSolve were instead handled by code inside the function
% that defined the problem instance.

% The vectorization used in this file is similar in efficiency to using
% explicit loops over indices when dim=20, but much faster when dim>=100
% (loops are better when dim=5, say).


% initial guess (updated in each call and used in the next) 
xx = (xlo+xup)/2;
iters = 0;

% allocate space to be used in all subsequent calls
lo = zeros(size(xx));
up = zeros(size(xx));
f = zeros(size(xx));
f1 = zeros(size(xx));
f2 = zeros(size(xx));
g = zeros(size(xx));
g1 = zeros(size(xx));
g2 = zeros(size(xx));
xi = zeros(size(xx));
hx = zeros(size(xx)); % h denotes f1+rho*g1
hlo = zeros(size(xx));
hup = zeros(size(xx));
dhx = zeros(size(xx));
r = zeros(size(xx));
d = zeros(size(xx));
t = zeros(size(xx));
xt = zeros(size(xx));
hxt = zeros(size(xx));

% prep the return argument
subSolve = @subSolveRoutine;

    function [x,status]=subSolveRoutine(rho,Iinput,timeout)
        I = false(size(xx));
        I(Iinput) = true;
        interval(rho,I); % create interval lo,up
        II = false(size(I)); % indices completed
        
        % trivial cases
        J = I;
        J(J) = lo(J)==up(J);
        if any(J)
            xx(J) = lo(J);
            I = I&~J; II = II|J; % move J from I to II
        end
        
        if any(I)
            % prepare bracket values
            tol = 1e-8;
            [f(I),f1(I)] = obj(lo(I),I);
            [g(I),g1(I)] = con(lo(I),I);
            hx(I) = f1(I)+rho*g1(I);
            xi(I) = lo(I);
            [f(I),f1(I)] = obj(up(I),I);
            [g(I),g1(I)] = con(up(I),I);
            hup(I) = f1(I)+rho*g1(I);
            J = I;
            J(J) = abs(hx(J))>abs(hup(J));
            if any(J)
                xi(J) = up(J);
                hx(J) = hup(J);
            end

            r(I) = tol*(abs(hx(I))+1);

            % check for convergence
            J = I;
            J(J) = abs(hx(J))<=r(J);
            xx(J) = xi(J);
            I = I&~J; II = II|J; % move J from I to II
        end
        
        status = 0;
        while any(I)
            iters = iters+1;
            if mod(iters,100)==0&&timeout(), status=1; x=xx(I|II); return, end
            
            % get derivative at current iterate
            [f(I),f1(I),f2(I)] = obj(xi(I),I);
            [g(I),g1(I),g2(I)] = con(xi(I),I);
            dhx(I) = f2(I)+rho*g2(I);
            
            J = I;
            J(J) = dhx(J)==0|isinf(dhx(J))|isnan(dhx(J));
            if any(J) % derivative is useless
                % bisect
                xi(J) = lo(J)+(up(J)-lo(J))/2;
                [f(J),f1(J)] = obj(xi(J),J);
                [g(J),g1(J)] = con(xi(J),J);
                hx(J) = f1(J)+rho*g1(J);
            end
            
            J(I) = ~J(I); % otherwise...
            if any(J)
                % Newton direction
                d(J) = -hx(J)./dhx(J);
                % default step-size
                K = J;
                K(K) = d(K)>0;
                if any(K)
                    t(K) = min(1,(up(K)-xi(K))./d(K));
                end
                K(J) = ~K(J);
                if any(K)
                    t(K) = min(1,(lo(K)-xi(K))./d(K));
                end
                while any(J)
                    iters = iters+1;
                    if mod(iters,100)==0&&timeout(), status=1; x=xx(I|II); return, end
                    
                    % Armijo backtracking
                    xt(J) = xi(J)+t(J).*d(J);
                    [f(J),f1(J)] = obj(xt(J),J);
                    [g(J),g1(J)] = con(xt(J),J);
                    hxt(J) = f1(J)+rho*g1(J);
                    K = J;
                    K(K) = abs(hxt(K))<(1-t(K)*1e-4).*abs(hx(K));
                    if any(K)
                        xi(K) = xt(K);
                        hx(K) = hxt(K);
                        J = J&~K;
                    end
                    if any(J)
                        t(J) = t(J)/2;
                    end
                end
            end
            
            % update bracket
            J = I;
            J(J) = (hx(J)>0)==(hup(J)>0);
            if any(J)
                up(J) = xi(J);
                hup(J) = hx(J);
            end
            J(I) = ~J(I);
            if any(J)
                lo(J) = xi(J);
            end
            
            % check for convergence
            J = I;
            J(J) = abs(hx(J))<=r(J);
            xx(J) = xi(J);
            I = I&~J; II = II|J; % move J from I to II
        end
        
        x = xx(II);
    end

    function interval(rho,I)
        % Adjusts initial interval to bracket the new solution x(i).

        lo(I) = xlo(I);
        up(I) = xup(I);
        [f(I),f1(I)] = obj(lo(I),I);
        [g(I),g1(I)] = con(lo(I),I);
        hlo(I) = f1(I)+rho*g1(I);
        [f(I),f1(I)] = obj(up(I),I);
        [g(I),g1(I)] = con(up(I),I);
        hup(I) = f1(I)+rho*g1(I);

        % use old value of x if it improves the interval
        J = I;
        J(J) = (xx(J)<lo(J))&(hlo(J)>0);
        if any(J) % max(x,new) < lo < up
            up(J) = lo(J);
            lo(J) = xx(J);
            [f(J),f1(J)] = obj(lo(J),J);
            [g(J),g1(J)] = con(lo(J),J);
            hlo(J) = f1(J)+rho*g1(J);
        end
        J = I;
        J(J) = (xx(J)>up(J))&(hup(J)<0);
        if any(J) % lo < up < min(x,new)
            lo(J) = up(J);
            up(J) = xx(J);
            [f(J),f1(J)] = obj(up(J),J);
            [g(J),g1(J)] = con(up(J),J);
            hup(J) = f1(J)+rho*g1(J);
        end
        J = I;
        J(J) = (lo(J)<xx(J))&(xx(J)<up(J));
        if any(J) % lo < x < up
            K = J;
            K(K) = hlo(K)>0;
            if any(K) % new < lo < x < up
                up(K) = xx(K);
                [f(K),f1(K)] = obj(up(K),K);
                [g(K),g1(K)] = con(up(K),K);
                hup(K) = f1(K)+rho*g1(K);
            end
            K = J;
            K(K) = hup(K)<0;
            if any(K) % lo < x < up < new
                lo(K) = xx(K);
                [f(K),f1(K)] = obj(lo(K),K);
                [g(K),g1(K)] = con(lo(K),K);
                hlo(K) = f1(K)+rho*g1(K);
            end
            K = J;
            K(K) = (hlo(K)<0)&(0<hup(K));
            if any(K) % lo < both(x,new) < up
                [f(K),f1(K)] = obj(xx(K),K);
                [g(K),g1(K)] = con(xx(K),K);
                hx = zeros(size(xx));
                hx(K) = f1(K)+rho*g1(K);
                J = K;
                J(J) = hx(J)<=0;
                if any(J) % lo < x <= new < up
                    lo(J) = xx(J);
                    hlo(J) = hx(J);
                end
                J = K;
                J(J) = hx(J)>0;
                if any(J) % lo < new < x < up
                    up(J) = xx(J);
                    hup(J) = hx(J);
                end
            end
        end

        % check trivial cases
        J = I;
        J(J) = hlo(J)==0|(xlo(J)==lo(J)&hlo(J)>0);
        if any(J)
            up(J) = lo(J);
            I(J) = false;
        end
        J = I;
        J(J) = hup(J)==0|(xup(J)==up(J)&hup(J)<0);
        if any(J)
            lo(J) = up(J);
        end
        
    end % function interval


end % function setsubSolver


