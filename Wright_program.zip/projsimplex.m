function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    projsimplex(dim,p,internal)
% problem data for weighted l_p projection onto a simplex and box

if nargin<2
    p = 2;
end
y = randn(dim,1).^2; % vector being projected
a = 1 + 4*rand(dim,1); % 1 < a < 5
lo = 1.5 * y.*rand(dim,1); % 0 < lo < 5
up = lo + (3*y-lo) .* rand(dim,1); % lo < up < 5
% choose rhs last to guarantee feasibility
arhs = cumsum(lo + (up-lo).*rand(dim,1));

% function handles
obj = @objective;
lincon = ones(size(up));
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

if nargin<3||internal
    subSolve = @subSolverRoutine;
    pegSolve = @pegSolverRoutine;
    interSolve = @interSolverRoutine;
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        xmy = x-y(index);
        axy = abs(xmy);
        if nargout==1
            f = a(index).*axy.^p;
        elseif nargout==2
            f1 = p*a(index).*xmy.*axy.^(p-2);
            f = f1.*xmy/p;
        else
            f2 = p*(p-1)*a(index).*axy.^(p-2);
            f1 = f2.*xmy/(p-1);
            f = f1.*xmy/p;
        end
    end

    function [xh,status] = subSolverRoutine(lambda,I,~)
        ratio = (lambda/p)./a(I);
        xh = y(I)-sign(ratio).*abs(ratio).^(1/(p-1));
        status = 0;
    end
    function [x,status] = pegSolverRoutine(M,rhs,~)
        num = sum(y(M))-rhs;
        den = sum(a(M).^(1/(1-p)));
        lambda = sign(num)*p*abs(num/den).^(p-1);
        x = subSolverRoutine(lambda,M);
        status = 0;
    end
    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,M,rhs,~)
        num = sum(y(M))-rhs;
        den = sum(a(M).^(1/(1-p)));
        lambda = sign(num)*p*abs(num/den).^(p-1);
        lambda = max(lambda_lo,min(lambda,lambda_up));
        x = subSolverRoutine(lambda,M);
        status = 0;
   end


end % projsimplex

