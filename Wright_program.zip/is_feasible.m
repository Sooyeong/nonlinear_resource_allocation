function feas=is_feasible(aindex,arhs,eqrhs,weight,lo,up)
% determines whether the nested constraints are feasible

feas = false; % assume infeasible and return as soon as this is justified
if any(weight<0)||any(lo>up), return, end

wlo = weight.*lo;
wup = weight.*up;
if sum(wlo)>eqrhs||sum(wup)<eqrhs, return, end

k = length(aindex);
if k>1
    cwlo = cumsum(wlo);
    if any(cwlo(aindex)>arhs), return, end
    cwup = cumsum(wup);
    dcwup = diff(cwup(aindex));
    
    arhs_prev = min(arhs(1),cwup(aindex(1)));
    for i=2:k
        arhs_prev = min(arhs(i),arhs_prev+dcwup(i-1));
    end
    if arhs_prev+cwup(end)-cwup(aindex(end))<eqrhs, return, end
end

feas = true;
end