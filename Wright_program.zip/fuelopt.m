function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    fuelopt(dim,internal)
% FuelOpt
p=unifrnd(0.8,1.2,dim,1);
% c-> lower bound
lo=unifrnd(0.7,1,dim,1);
obj_coeff = p.*lo.^4;
%d-> upper bound
up=lo*1.5;
%Alpha_i follows uniform with 
arhs=cumsum(unifrnd(1,1.2,dim,1));

% function handles
obj=@objective;
lincon=ones(size(lo));
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

% all closed-form solvers
if nargin<2||internal
    breakpt_coeff = lo.*(3*p).^(1/4);
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
    pegSolve = @pegSolverRoutine;
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end


% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        f = obj_coeff(index)./x.^3;
        if nargout > 1
            f1 = -3*f./x;
            if nargout > 2
                f2 = -4*f1./x;
            end
        end
    end % objective function

    function [x,status]=subSolverRoutine(lambda,I,~)
        % minimize sum(obj(x,I))+lambda*lincon(I)*x) over x
        x = breakpt_coeff(I)/lambda^(1/4);
        status = 0;
    end

    function [x,status] = pegSolverRoutine(I,rhsI,~)
        % minimize sum(obj(x,I)) s.t. sum(lincon(I)*x)==rhsI
        lambda = (sum(breakpt_coeff(I))/rhsI)^4;
        x = subSolverRoutine(lambda,I);
        status = 0;
    end

    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,I,rhsI,~)
        lambda = (sum(breakpt_coeff(I))/rhsI)^4;
        lambda = max(lambda_lo,min(lambda,lambda_up));
        x = subSolverRoutine(lambda,I);
        status = 0;
    end

end