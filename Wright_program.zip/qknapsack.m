function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    qknapsack(dim,dataversion,internal)
% Quadratic Knapsack & Quadratic Resource Allocation problem data

if nargin<2
    dataversion = 1;
end
switch dataversion
    case 1 % uncorrelated
        p = 10 + (25-10) .* rand(dim,1); % 10 < p < 25
        a = 10 + (25-10) .* rand(dim,1); % 10 < a < 25
        b = 10 + (25-10) .* rand(dim,1); % 10 < b < 25
    case 2 % weakly correlated
        b = 10 + (25-10) .* rand(dim,1); % 10 < b < 25
        p = (b-5) + ((b+5)-(b-5)) .* rand(dim,1); % b-5 < p < b+5
        a = (b-5) + ((b+5)-(b-5)) .* rand(dim,1); % b-5 < a < b+5
    case 3 % strongly correlated
        b = 10 + (25-10) .* rand(dim,1); % 10 < b < 25
        p = b + 5;
        a = b + 5;
    case 4 % Kiwiel forces p_i to be equal
        p = ones(dim,1) * (10 + (25-10) .* rand(1)); % 10 < p < 25
        % uncorrelated
        a = 10 + (25-10) .* rand(dim,1); % 10 < a < 25
        b = 10 + (25-10) .* rand(dim,1); % 10 < b < 25
end
lo = 1.5*(a./p).*rand(dim,1);
up = lo + (3*(a./p)-lo) .* rand(dim,1);
lincon = b;
% choose rhs last to guarantee feasibility
arhs = cumsum(b.*lo+b.*(up-lo).*rand(dim,1));

% function handles
obj = @objective;
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

if nargin<3||internal
    adivp = a./p;
    bdivp = b./p;
    abdivp = adivp.*b;
    b2divp = bdivp.*b;
    subSolve = @subSolverRoutine;
    pegSolve = @pegSolverRoutine;
    interSolve = @interSolverRoutine;
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        f = (1/2)*p(index).*x.^2 - a(index).*x;
        if nargout > 1
            f1 = p(index).*x - a(index);
            if nargout > 2
                f2 = p(index);
            end
        end
    end % objective

    function [xh,status] = subSolverRoutine(lambda,I,~)
        xh = adivp(I) - lambda*bdivp(I);
        status = 0;
    end
    function [x,status] = pegSolverRoutine(M,rhs,~)
        lambda_top = sum(abdivp(M)) - rhs;
        lambda_bottom = sum(b2divp(M));
        lambda = lambda_top/lambda_bottom;
        x = subSolverRoutine(lambda,M);
        status = 0;
    end
    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,M,rhs,~)
        lambda_top = sum(abdivp(M)) - rhs;
        lambda_bottom = sum(b2divp(M));
        lambda = lambda_top/lambda_bottom;
        lambda = max(lambda_lo,min(lambda,lambda_up));
        x = subSolverRoutine(lambda,M);
        status = 0;
    end
end % qknapsack

