% Pseudocode for intersSolver NM

% Check multiple inflection point in the original problem
% If multiple inflection is ture then use this setinterSolver_lincon_NM.

function interSolve=setinterSolver_lincon_NM(obj,lincon,dom,subSolve,rholo,rhoup,initial)
% Get optional initial value from each problem.
rho=initial
% Newton bisect method 
while(Phi(rho)~=0 && abs(tolerance)<=criterion){
    rho=rho-(Phi(rho)/Phi1(rho)
    if(rho<lo_rho||rho>up_rho){
        rho=(lo_rho+up_rho)/2
        }
    end
    if(sgn(Phi(rho))==sgn(Phi(lo_rho))){
        lo_rho=rho
        }
    else if(sgn(Phi(rho)==sgn(Phi(up_rho))){
            up_rho=rho
     }
        end
}

end
    