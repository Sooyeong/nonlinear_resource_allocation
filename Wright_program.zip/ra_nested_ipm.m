function [x,status] = ra_nested_ipm(...
    obj,aindex,arhs,eqrhs,weight,lo,up,timeout)
% Nested resource allocation via interior-point method.
%
% x = ra_nested_ipm(obj,aindex,arhs,eqrhs,weight,a,rhs,lo,up) minimizes
%     sum(obj(x)) over all x with lo <= x <= up and all y
%     s.t. y == cumsum(weight.*x), y(aindex) <= arhs, y(end) == eqrhs.
%
% Assumes:
%   * obj is called as [f,f1,f2] = obj(x) to obtain a vector of values for
%       which f(i) corresponds to a convex, twice-differentiable function
%       of x(i) (returning 1st and 2nd derivatives f1 and f2 as needed)
%       [Note: f(I)=obj(x(I),I) returns selected components of obj.]
%   * aindex is an index vector (numeric or logical) for a subset of 1:n-1
%   * arhs is a positive vector
%   * eqrhs is a positive scalar
%   * weight is a positive vector
%   * lo and up are finite with lo<up, and the domain of f(i) contains the
%       the open interval lo(i)<x(i)<up(i)
%   * problem is feasible

% Note: The following code assumes that the vectors weight, lo, up are the
% same shape (row or column) as vectors returned by obj. It also assumes
% that length(arhs) equals length(aindex) if aindex is numeric or
% nnz(aindex) if aindex is logical.

% Notation used in the code: Assuming column vectors, the problem is framed
% as
%     minimize sum(obj(x+lo)) over all x s.t.
%       0 <= x <= u, (K*diag(weight))*x <= a, weight'*x == b
% where
%
%  * n = length(x), k = length(arhs)
%  * Ja is logical of length n, corresponding to same subset as aindex
%  * K = L(Ja,:), where L=tril(ones(n)) [K is never formed explicitly]
%  * sigma is the barrier parameter
%  * s is the vector of slacks for the upper bounds
%  * lambda is the vector of multipliers for the lower bounds
%  * mu is the vector of multipliers for the upper bounds
%  * xi is the vector of slacks for the inequality constraints
%  * eta is the vector of multipliers for the inequality constraints
%  * rho is the (scalar) multiplier for the equality constraint
%  * u = up-lo, a = arhs-K*(weight.*lo), b = eqrhs-weight'*lo to achieve
%      the effect of shifting x so it is nonnegative
%
% The barrier-perturbed KKT conditions are:
%
%  f1 + weight*rho + diag(weight)*K'*eta - lambda + mu = zeros(n,1) [r1]
%  diag(x)*lambda = (sigma/4)*ones(n,1)                             [r2]
%  x + s = u                                                        [r3]
%  diag(s)*mu = (sigma/4)*ones(n,1)                                 [r4]
%  diag(xi)*eta = (sigma/4)*ones(k,1)                               [r5]
%  K*diag(weight)*x + xi = a                                        [r6]
%  weight'*x = b                                                    [r7]
%  x>0, s>0, xi>0, lambda>0, mu>0, eta>0
%
% with tau=sigma/4 for sigma = (x'*lambda + s'*mu + xi'*eta)/(2*n+k). The
% residuals LHS-RHS are labeled on the right. As a feasible IPM, the
% algorithm maintains r3==0, r6==0, r7==0 at all times.

% test this input first
if any(weight<=0), error('Input weights must be positive.'), end

status = 0;

n = length(up);
Ja = false(size(lo));
Ja(aindex) = true; % create logical-index version of aindex
k = nnz(Ja); % number of inequality constraints

% Reorder arhs if necessary 
if ~islogical(aindex) % aindex is numeric indexing
    % reorder to match aindex if aindex were sorted in increasing order
    arhs_full = zeros(size(lo));
    arhs_full(aindex) = arhs;
    arhs = arhs_full(Ja);
end

% Recast problem with lower bounds at zero
u = up-lo;
LWx = cumsum(weight.*lo);
a = arhs-LWx(Ja);
b = eqrhs-LWx(end);

% Initialize primal variables
% x : need strict feasibility
[x,a] = feasibility(find(Ja),a,b,weight,u); % also tightens constraint RHS
gaptol = 1e-10;
if any(isnan(x)) % infeasible
    x(:) = nan; status = 1; return
elseif any(u<=gaptol)||any(x==u)||any(x==0)
    % no strictly feasible point, or u is too close to zero
    I = (0<x)&(x<u)&(u>gaptol);
    if any(I)
        Ja(~I) = false;
        x(I) = 0;
        LWx = cumsum(weight.*x);
        Inum = find(I);
        [x(I),status] = ra_nested_ipm(...
            @(x,II)obj(x+lo(Inum(II)),Inum(II)),...
            Ja,a(1:nnz(Ja))-LWx(Ja),b-LWx(end),...
            weight(I),zeros(size(x(I))),u(I),...
            timeout);
        % Note: this might be incorrect in boundary cases where slack rows
        % need not be consecutive among original rows.
    end
    x = x+lo;
    return
end
% s : full slack for upper bounds [algorithm assumes x+s==u always]
s = u-x;
% xi : full slack for inequalities [algorithm assumes K*W*x+xi==a]
LWx = cumsum(weight.*x);
xi = a-LWx(Ja);

% Initialize dual variables
% rho : dumb choice
rho = 1;
% eta : must be positive
eta = ones(size(a));
Kt_eta = zeros(n,1);
Kt_eta(Ja) = eta;
Kt_eta = flip(cumsum(flip(Kt_eta))); % K'*eta
% lambda, mu : satisfy Lagrange multiplier equation, pad to be positive
[~,f1,f2] = obj(x+lo,true(size(lo)));
LM = f1+weight.*(rho+Kt_eta);
lambda = max(0,LM)+1;
mu = max(0,-LM)+1;

% Residuals
r1 = LM-lambda+mu;
r2 = lambda.*x;
r4 = mu.*s;
r5 = eta.*xi;
res2 = sum(r2);
res4 = sum(r4);
res5 = sum(r5);

% Barrier parameter based on current duality gap
sigma = (res2+res4+res5)/(2*n+k);

% Convergence criteria
normKw = sum(weight)*(k+1);
sum_lam = sum(lambda);
sum_mu = sum(mu);
sum_eta = sum(eta);
res = [
    sum(abs(r1))/(1+sum(abs(f1))+abs(rho)+normKw+sum_lam+sum_mu+sum_eta)
    res2/(1+sum(x)+sum_lam)
    res4/(1+sum(s)+sum_mu)
    res5/(1+sum(xi)+sum_eta)
    ];

% Tolerances and parameters
res_tol = 1e-10; % required relative norm of residuals (1e-8<sqrt(eps))
damping = .99; % initial proportion of step toward boundary
sigfac = .05; % sigma reduction target

% Primal-Dual IPM
loop = 0;
while any( res > res_tol)
    
    % Begin loop
    loop = loop + 1;
    if mod(loop,100)==0&&timeout(), status = 1; return, end
    
    % Adjust barrier parameter
    r2 = r2 - sigfac*sigma;
    r4 = r4 - sigfac*sigma;
    r5 = r5 - sigfac*sigma;
    
    % Solve the Newton system
    [dx,dlambda,ds,dmu,dxi,deta,drho] = ...
        solveNewton(weight,Ja,x,lambda,s,mu,xi,eta,f2,r1,r2,r4,r5);

    % Find the step-length to the boundary in all variables
    I = dx>0;
    xstep = min(x(I)./dx(I));
    I = dlambda>0;
    lamstep = min(lambda(I)./dlambda(I));
    I = ds>0;
    sstep = min(s(I)./ds(I));
    I = dmu>0;
    mustep = min(mu(I)./dmu(I));
    J = dxi>0;
    xistep = min(xi(J)./dxi(J));
    J = deta>0;
    etastep = min(eta(J)./deta(J));
    step = damping*min([xstep,lamstep,sstep,mustep,xistep,etastep]);
    
    % Step-size and update
    t = min(1,step);
    x = x-t*dx;
    lambda = lambda-t*dlambda;
    s = s-t*ds;
    mu = mu-t*dmu;
    xi = xi-t*dxi;
    eta = eta-t*deta;
    rho = rho-t*drho;
     
    % Residuals and barrier parameter
    Kt_eta(~Ja) = 0;
    Kt_eta(Ja) = eta;
    Kt_eta = flip(cumsum(flip(Kt_eta))); % K'*eta
    r2 = lambda.*x;
    r4 = mu.*s;
    r5 = eta.*xi;
    res2 = sum(r2);
    res4 = sum(r4);
    res5 = sum(r5);
    sigma = (res2+res4+res5)/(2*n+k);
    
    % Objective derivatives, LM residuals, onvergence criteria
    [~,f1,f2] = obj(x+lo,true(size(lo)));
    r1 = f1+weight.*(rho+Kt_eta)-lambda+mu;
    sum_lam = sum(lambda);
    sum_mu = sum(mu);
    sum_eta = sum(eta);
    res = [
        sum(abs(r1))/(1+sum(abs(f1))+abs(rho)+normKw+sum_lam+sum_mu+sum_eta)
        res2/(1+sum(x)+sum_lam)
        res4/(1+sum(s)+sum_mu)
        res5/(1+sum(xi)+sum_eta)
        ];

end % while loop

% End of IPM

% Return solution
x = x+lo;
%loop

end % MAIN function ra_ipm


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% HELPER function solveNewton

function [dx,dlambda,ds,dmu,dxi,deta,drho] = ...
    solveNewton(w,Ja,x,lambda,s,mu,xi,eta,f2,r1,r2,r4,r5)
% Sparse solution of the Newton equation for the KKT conditions

% The coefficient matrix has the form
%
%  [  f2           -I      0        I       0         diag(w)*K' w
%     diag(lambda) diag(x) 0        0       0         0          0
%     I            0       I        0       0         0          0
%     0            0       diag(mu) diag(s) 0         0          0
%     0            0       0        0       diag(eta) diag(xi)   0
%     K*diag(w)    0       0        0       I         0          0
%     w'           0       0        0       0         0          0  ]
%
% with columns in the same order as the output arguments and RHS given by
% residuals r1,r2,0,r4,r5,0,0. The matrix K = L(Ja,:) with L=tril(ones(n))
% is not formed explicitly. (It's assumed that Ja(end) is false.)
%
% For explicit full matrix K, a nearly closed-form solution would be:
%    n = length(x);
%    L = tril(ones(n));
%    e = ones(n,1);
%    K = L(Ja,:)
%    q = (f2+lambda./x+mu./s)./w./w;
%    r1hat = (r1+r2./x-r4./s)./q./w;
%    detadrho = ...
%       ([K;e']*diag(1./q)*[K',e]+diag([xi./eta;0])) ...
%        \ [K*r1hat+r5./eta;sum(r1hat)];
%    deta = detadrho(1:end-1);
%    drho = detadrho(end);
%    dxi = (r5-xi.*deta)./eta;
%    dx = (r1hat - (K'*deta+drho)./q)./w;
%    dlambda = (r2-lambda.*dx)./x;
%    ds = -dx;
%    dmu = (r4-mu.*ds)./s;
% However, there are some redundancies in this. For the sake of speed, the
% code below precalculates some expressions by reusing these variables:

r2 = r2./x;
r4 = r4./s;
r5 = r5./eta;
lambda = lambda./x;
mu = mu./s;
xi = xi./eta;
f2 = w./(f2+lambda+mu);
r1 = (r1+r2-r4).*f2; % r1hat
f2 = w.*f2; % 1./q

% With the above transformation, the solution with an explicit full matrix
% K would become:
%    n = length(x);
%    L = tril(ones(n));
%    e = ones(n,1);
%    K = L(Ja,:);
%    detadrho = ([K;e']*diag(f2)*[K',e]+diag([xi;0])) \ [K*r1+r5;sum(r1)];
%    deta = detadrho(1:end-1);
%    drho = detadrho(end);
%    dxi = r5-xi.*deta;
%    dx = (r1 - (K'*deta+drho).*f2)./w; 
%    dlambda = r2-lambda.*dx;
%    ds = -dx;
%    dmu = r4-mu.*ds;

k = length(xi); % this is nnz(Ja)=length(eta)=length(xi)=length(r5) 

% detadrho calculation simplifies when k=0
if k==0
    deta = zeros(size(eta));
    drho = sum(r1)/sum(f2);
    dxi = zeros(size(xi));
    dx = (r1-drho*f2)./w;
    dlambda = r2-lambda.*dx;
    ds = -dx;
    dmu = r4-mu.*ds;
    return
end

% Otherwise, the actual code implements a linear-time solver using only an
% implicit representation of the matrix K and vector e. Complexity is
%    8n+13k-2 assignments
%    3n+21k-4 indexed array references
%           4 function calls (1 to length, 3 to cumsum)
%   11n+10k-6 adds/subtracts (plus 2k-3 loop counter increments/decrements)
%    5n+ 4k+1 multiplies
%    6n+ 4k+2 divides

% set up coefficients of linear system
x = cumsum(r1); % L*r1
deta = x(Ja)+r5; % rhs = K*r1+r5
s = cumsum(f2); % L*f2
s(1:k) = s(Ja); % off-diagonal entries (K*f2)
x(1:k) = s(1:k)+xi; % diagonal entries (K*f2+xi)

% forward elimination
ad = s(1)/x(1);
sum1 = s(1)*ad;
sum2 = deta(1)*ad;
for j=2:k
    x(j) = x(j) - sum1;
    s(j) = s(j) - sum1;
    deta(j) = deta(j)-sum2;
    ad = s(j)/x(j);
    sum1 = sum1+s(j)*ad;
    sum2 = sum2+deta(j)*ad;
end

% backward substitution
drho = (x(end)-sum2)/(s(end)-sum1);
sum1 = drho;
for j=k:-1:1
    deta(j) = (deta(j)-s(j)*sum1)/x(j);
    sum1 = sum1+deta(j);
end

dxi = r5-xi.*deta;
s(:) = 0;
s(Ja) = deta;
s = flip(cumsum(flip(s))); % K'*deta
dx = (r1 -(s+drho).*f2)./w; % better to input invw=1./w?
dlambda = r2-lambda.*dx;
ds = -dx;
dmu = r4-mu.*ds;

end % function solveNewton

function [x,a]=feasibility(aindex,a,b,weight,u)
% Find a strictly feasible point, if possible, so that 
%     0 < x < u, L(aindex,:)*(weight.*x) < a, weight'*x == b
% Adjusts values in a-vector so that they're monotone and reflect any
% tightening suggested by u. Returns x as all NaN if infeasible. Returns x
% with some entries equal to values in u if not strictly feasible.
%
% Assumes: weight is positive; aindex (if nonempty) is numeric and
% increasing; weight and u have same shape.

sz = size(u);

% first handle easy cases
if b<0||any(u<0)||any(a<0)||(b>0&&all(u==0))
    x = nan(sz);
    return
elseif b==0 % only the trivial solution is possible
    x = zeros(sz);
    a(:) = 0;
    return
elseif isempty(aindex)
    w_u = sum(weight.*u);
    if w_u<b
        x = nan(sz);
    else
        % 0<x<u where possible, with sum(weight.*x)==b
        x = u*(b/w_u); % note: x(i) = 0 if u(i)==0
    end
    return
end

% rescale bounds by weight, then solve feasibility problem as if weight=1
u = u.*weight;

% calculate totals of upper bounds within blocks determined by aindex
u_cumsum = cumsum(u(:));
ublk = diff([0;u_cumsum(aindex)]);
ublk_end = u_cumsum(end)-u_cumsum(aindex(end));

% enforce monotonicity of a
a(end) = min(a(end),b);
for j=length(a)-1:-1:1
    a(j) = min(a(j),a(j+1));
end

% use upper bounds to tighten a
a(1) = min(a(1),ublk(1));
for j=2:length(a)
    a(j) = min(a(j),a(j-1)+ublk(j));
end

% test for infeasibility
if a(end)+ublk_end < b
    x = nan(sz);
    return
end

% identify non-redundant constraints
J = flip(diff([0;b;flip(a(:))])~=0);
J(end) = false;

% return the solution, rescaled to reflect actual weights
x = reshape( strictfeas(aindex(J),a(J),b,u) ,sz)./weight;

end % function feasibility

function x=strictfeas(aindex,a,b,u)
% Find a strictly feasible point, if possible, so that 
%     0 < x < u, L(aindex,:)*(weight.*x) < a, weight'*x == b
% Assumes feasibility and no redundant rows.

% recalculate blocks for reduced problem
u_cumsum = cumsum(u(:));
ublk = diff([0;u_cumsum(aindex)]);
ublk_end = u_cumsum(end)-u_cumsum(aindex(end));

% decide which blocks of variables must be fixed at their upper bounds
jslack = length(a); % highest index of an inequality that can be slack
ifix = length(u)+1;
if a(jslack)+ublk_end==b
    ifix = aindex(jslack)+1;
    jslack = jslack-1;
    while jslack>0 && a(jslack)+ublk(jslack+1)==a(jslack+1)
        ifix = aindex(jslack)+1;
        jslack = jslack-1;
    end
    if jslack==0 && ublk(1)==a(1)
        ifix = 1;
    end
end

% choose strictly feasible values for x(1:ifix-1)
x = u; % initialize (this choice is useful below)
if ifix>1
    x(1:aindex(1)) = u(1:aindex(1))*a(1)/ublk(1);
    for j=2:jslack
        x(aindex(j-1)+1:aindex(j)) = ...
            u(aindex(j-1)+1:aindex(j))*(a(j)-a(j-1))/ublk(j);
    end
    if jslack==length(a)
        x = x*b/sum(x);
    else
        x(1:aindex(jslack+1)) = ...
            x(1:aindex(jslack+1))*a(jslack+1)/sum(x(1:aindex(jslack+1)));
    end
end
end % function strictfeas
