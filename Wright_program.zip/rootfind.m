function [x,status]=rootfind(f,xlo,xup,x,timeout)
% Given f, find x (between xlo and xup) such that f(x)=0. Start at the
% input value of x if it is nonempty

status = 0;

% check for errors or easy solutions and act accordingly
if nargin<3
    error('f and two endpoints are required inputs')
end
if xlo>xup % flip endpoints
    xdum = xlo; xlo = xup; xup = xdum;
end
fxlo = f(xlo);
if fxlo==0
    x = xlo; return
end
fxup = f(xup);
if fxup==0
    x = xup; return
end
if sign(fxlo)==sign(fxup)
    status = 1; return
end
if nargin<4 || isempty(x) || x<xlo || x>xup
    x = (xlo+xup)/2;
end
if nargin<5 || isempty(timeout)
    timeout = @()false; % run forever
end

[fx,f1x] = f(x);
dx = inf;

tol = 1e-11; % numerical tolerance for termination criterion
iters = 0; % iteration count - only used in checking for excessive runtime

while fx~=0 ... % did not find root exactly
        && xup-xlo>tol*max(abs(xlo),abs(xup)) ... % bracket is large
        && abs(dx)>tol*abs(x) % Newton step is large
    
    iters = iters+1;
    if mod(iters,100)==0&&timeout(), status=1; return, end
    
    dx = fx/f1x; % Newton step
    x = x - dx;
    if x<xlo || x>xup % Newton's method escapes the bracket
        dx = inf; % discard Newton step
        x = (xlo+xup)/2; % bisect interval as failsafe
    end
    [fx,f1x] = f(x);
    
    if sign(fxlo)==sign(fx)
        xlo = x; fxlo = fx;
    elseif sign(fxup)==sign(fx)
        xup = x; fxup = fx;
    end
        
end
end