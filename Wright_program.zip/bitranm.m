function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    bitranm(dim,internal)
% problem data related to Bitran & Mondschein's

% Operational model: given inventory levels (set by higher authority) and
% demand distributions, choose order levels to maximize profit.  The
% decision variable is inventory+order, constrained to exceed inventory.

% For a probability density h(t), the objective f is defined as
%   f = d*( a*x*int(h(t),0,x) - (1+a)*int(t*h(t),0,x)
%           + b*int(t*h(t),x,inf) - (1+b)*x*int(h(t),x,inf) ) ,
%   f1 = d*(  a*int(h(t),0,x) - (1+b)*int(h(t),x,inf) ) ,
%   f2 = d*(1+a+b)*h(x).
% We assume h(t) is the Normal(mu,sigma) density, and therefore use the
% standard normal density and cdf
%   phi(z) = exp(-z^2/2) / sqrt(2*pi),
%   Phi(z) = erfc(-z/sqrt(2))  / 2
% to calculate
%   h(t) = phi((t-mu)/sigma) / sigma ,
%   int(h(t),alpha,beta) = Phi((beta-mu)/sigma) - Phi((alpha-mu)/sigma) ,
%   int(t*h(t),alpha,beta) =
%          mu*( Phi((beta-mu)/sigma) - Phi((alpha-mu)/sigma) )
%            - sigma*( phi((beta-mu)/sigma) - phi((alpha-mu)/sigma) ) .
% Terms involving alpha=0 and beta=inf are precalculated for reuse.

% coefficients
a = .2; % holding cost as fraction of selling price
b = .1; % shortage cost as fraction of selling price
c = .35*ones(dim,1); % item cost as fraction of selling price
d = 20+100*rand(dim,1); % selling price
mu = 5000+10000*rand(dim,1); % MEAN(demand)
sigma = mu.*(.05+.05*rand(dim,1)); % STD(demand) = 5-10% of mean

% define and retain auxiliary quantities used in obj and subSolve
dab = d*(1+a+b);
Phi0 = erfc(mu./sigma/sqrt(2))/2;
linear = d.*(a*Phi0+1+b);
constant = d.*(...
    (1+a)*(mu.*Phi0-sigma.*exp(-(mu./sigma).^2/2)/sqrt(2*pi))...
    + b*(mu*1-sigma*0)); % constant could be omitted, but it costs little
v = c./dab;
u = linear./dab;
cv_sigma = c.*v.*sigma;

% pre-allocate arrays used by subSolve and interSolve
xtmp = zeros(size(linear));
uv_lambda = zeros(size(linear));
J = false(size(c));

% choose bounds above mu-2*sigma
critpt = subSolverRoutine(0,true(dim,1));
mu2sig = mu-2*sigma;
up = mu2sig + (1.1*critpt - mu2sig).*rand(dim,1);
lo = mu2sig + .9*(up-mu2sig).*rand(dim,1); % lo=inventory
% choose arhs to be bracketed by sums of c.*lo and c.*up
arhs = cumsum(c.*lo + c.*(up-lo).*rand(dim,1));

iters = 0;

% function handles
obj = @objective;
lincon = c;
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

% closed-form subSolve available, but no pegSolve or interSolve
if nargin<2||internal
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end

% Pegging frequently fails because an unconstrained subproblem has no
% solution.  For example, in subSolve the derivative f1 has bounded range,
% so some values -rho*g1 yield unconstrained subproblems with solutions at
% x=+/-infinity.  (During computation, erfcinv returns NaN.)  Within the
% context of subSolve, we could simply assign x-values outside the problem
% bounds lo and up.  But because pegSolve performs much of its work outside
% the controlled context of subSolve, it must either enforce a separate set
% of bounds (defeating the purpose of pegging and making it uncompetitive)
% or else detect the unboundedness and somehow peg accordingly.

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        std = (x-mu(index))./sigma(index);
        dab_phi = dab(index).*exp(-std.^2/2)/sqrt(2*pi);
        dab_Phi = dab(index).*erfc(-std/sqrt(2))/2;
        f = sigma(index).*dab_phi + (x-mu(index)).*dab_Phi ...
            - linear(index).*x + constant(index);
        if nargout>1
            f1 = dab_Phi - linear(index);
            if nargout>2
                f2 = dab_phi./sigma(index);
            end
        end
    end

    function [xh,status] = subSolverRoutine(lambda,I,~)
        J(:) = false;
        J(I) = true;
        xtmp(J) = 0;
        uv_lambda(J) = u(J)-lambda*v(J);
        J(J) = uv_lambda(J)>0;
        xtmp(J) = mu(J) - sqrt(2)*sigma(J).*erfcinv(2*uv_lambda(J));
        xh = xtmp(I);
        status = 0;
    end

    function [x,status] = interSolverRoutine(rho_lo,rho_up,M,rhs,timeout)
        % Find the x that corresponds to rho having
        %     rhs==sum(c(M).*subSolve(rho,M)),   rho_lo<rho<rho_up.
        % Apply Newton's method initialized at the midpoint, with bisection
        % failsafe in case of numerical problems.

        status =0;
        tol = 1e-11;
        if length(M)==1
            % solution in closed form
            x = rhs/c(M);
            return
        end
        
        % bracket the root
        rho_width = rho_up-rho_lo;
        x = subSolverRoutine(rho_lo,M); % ignore status, timeout
        res_rho_lo = sum(c(M).*x)-rhs;
        x = subSolverRoutine(rho_up,M);
        res_rho_up = sum(c(M).*x)-rhs;
        
        % initial guess
        rho = (rho_lo+rho_up)/2;
        x = subSolverRoutine(rho,M);
        res_rho = sum(c(M).*x)-rhs;
        
        drho = inf; % no Newton step yet
        while res_rho~=0 ... % did not find root exactly
                && rho_up-rho_lo>tol*max(abs(rho_lo),abs(rho_up))... % wide bracket
                && abs(drho)>tol*max(1,abs(rho_width)) % large Newton step

            iters = iters+1;
            if mod(iters,100)==0&&timeout()
                status = 22;
                return
            end
            
            std = (x-mu(M))./sigma(M);
            dres = -sum(cv_sigma(M).*exp(std.^2/2))*sqrt(2*pi);
            drho = res_rho/dres; % Newton step
            rho = rho - drho;
            
            if rho>rho_up || rho<rho_lo % Newton step escapes bracket
                drho = inf; % discard Newton step
                rho = (rho_lo+rho_up)/2; % bisect interval as failsafe
            end
            
            x = subSolverRoutine(rho,M);
            res_rho = sum(c(M).*x)-rhs;
            
            % tighten bracket
            if sign(res_rho_lo)==sign(res_rho)
                rho_lo = rho;
                res_rho_lo = res_rho;
            elseif sign(res_rho_up)==sign(res_rho)
                rho_up = rho;
                res_rho_up = res_rho;
            end

        end
    end


end % bitranm
