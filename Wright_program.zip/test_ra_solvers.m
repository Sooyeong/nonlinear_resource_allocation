function [timing,status,objval] = test_ra_solvers(...
    problem,dim,maxtime,num_instances,repetitions,methods,internal,prt)
% Time trials for optimizers
%   problem : function handle for data-defining routine
%   dim : problem dimension
%   maxtime : maximum runtime (seconds) per solver (default is infinity)
%   num_instances: number of instances to solve
%   repetitions : number of attempts for each instance and method
%   methods : structure array of methods
%   internal : true when internal subproblem solvers used (if available)

rng default
%rand('twister',5489), randn('state',0)

% function handle for checking if maximum runtime has been exceeded
if maxtime==inf
    timeout =@()false; % imposes no time restriction
else
    timeout = @()toc>maxtime; % imposes maximum time per solver
end
%%% Note: An alternative is to use ticID's by way of definitions
%%%    timingtool=@(t)@()false  vs.  timingtool=@(t)@()toc(t)>maxtime
%%% passed into solvers in the form  ra_ipm(...,timingtool(tic)) .
%%% However, it adds enough overhead to distort some timings.

nsolvers = length(methods);

% WARM UP RUNS
[data{1:9}] = problem(dim,internal);
for isolv=1:nsolvers
    tic
    [xx,status] = methods(isolv).solver(data,timeout);
end

% TIMINGS
objval = nan(num_instances,nsolvers);
timing = zeros(num_instances,nsolvers,repetitions);
status = zeros(num_instances,nsolvers,repetitions);
for instance=1:num_instances
    if prt, fprintf('instance = %d:',instance); end
    [data{1:9}] = problem(dim,internal);
    for isolv=1:nsolvers
        if prt, fprintf('  %s',methods(isolv).name); end
        for rep=1:repetitions
            begintime = cputime; %tic
            [xx,status(instance,isolv,rep)] = ...
                methods(isolv).solver(data,timeout);
            timing(instance,isolv,rep) = cputime-begintime; %toc;
        end
        objval(instance,isolv) = sum(data{1}(xx));
    end
    if prt, fprintf('\n'); end
end

end % function test_ra_solvers
