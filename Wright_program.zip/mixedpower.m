function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    mixedpower(dim,p_case,internal)
% problem data for:
%   obj = weighted sum of powers of absolute differences
%   con = sum of coordinates (simplex)
% create coordinate-level data


% p_case := 
% if 
%   p>2 --1, 
% 1<p<2 --2, 
% 0<p<1 --3,
%   p<0 --4 ;

if p_case==1
    p=2+2*rand(dim,1);
elseif p_case==2
    p=1+1*rand(dim,1);
elseif p_case==3
    p=0+1*rand(dim,1);
else
    p=-rand(dim,1);
end


y = randn(dim,1).^2; % vector being projected
a = 1 + 4*rand(dim,1); % 1 < a < 5
lo = 1.5 * y.*rand(dim,1); % 0 < lo < 5
up = lo + (3*y-lo) .* rand(dim,1); % lo < up < 5
% choose rhs last to guarantee feasibility: con(lo) < rhs < con(up)

% Maybe this lincon suggest that a_i==1?
lincon = ones(size(up)); 
arhs = cumsum(lo + (up-lo).*rand(dim,1));

% function handles
obj = @objective;
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

% closed-form subSolve, but not pegSolve or interSolve
if nargin<3||internal
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
    %interSolve = setinterSolver_lincon(@objective,lincon,dom,...
    %    @subSolverRoutine);
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        xmy = x-y(index);
        axy = abs(xmy);
        if nargout==1
            f = a(index).*axy.^p(index);
        elseif nargout==2
            f1 = p(index).*a(index).*xmy.*axy.^(p(index)-2);
            f = f1.*xmy./p(index);
        else
            f2 = p(index).*(p(index)-1).*a(index).*axy.^(p(index)-2);
            f1 = f2.*xmy./(p(index)-1);
            f = f1.*xmy./p(index);
        end
    end

% Verified 

    function [xh,status] = subSolverRoutine(lambda,I,~)
        ratio = (lambda./p(I))./a(I);
        xh = y(I)-sign(ratio).*abs(ratio).^(1./(p(I)-1));
        status = 0;
    end


% This part should be modified for the newton method
    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,M,rhs,timeout)
    
        inv_ap = 1./(a(M).*p(M));
        inv_pm1= 1./(p(M)-1);
        den = inv_ap.^inv_pm1;
        % ysum=sum of ksi
        ysum = sum(y(M));
        % Here Rho is noated as lambda,
        % p=q, a=w;
        phi_range = sum(den.*(sign(lambda_up)*abs(lambda_up).^inv_pm1 ...
            - sign(lambda_lo)*abs(lambda_lo).^inv_pm1));

        % Initialize lambda(rho)
        %{
        if lambda_lo>0
            lambda = lambda_lo;
        elseif lambda_up<0
            lambda = lambda_up;
        elseif lambda_lo==0
            lambda = lambda_lo+.01*(lambda_up-lambda_lo);
        else
            lambda = lambda_up+.01*(lambda_lo-lambda_up);
        end
        %}
        
        
        pi=abs(inv_pm1);
        pi_k=min(pi);
        
        % What if abs(rhs-ysum==sum(den)) 
        % Is this case prevented by the assumption?
        
        if abs(rhs-ysum)<sum(den)
            r_0=1;
        elseif abs(rhs-ysum)>sum(den)
            r_0=(sum(den)./abs(rhs-ysum)).^(pi_k);
        end
        % Set inital point r_0
        r=r_0;
        undone = abs(lambda_up-lambda_lo)>1e-10 & phi_range>1e-10;
        iters = 0;

        % Looping until reach the threshold
        
        while undone 
            iters = iters+1;
            if mod(iters,100)==0&&timeout()
                status=2;
                return
            end
            %term = den.*abs(lambda).^inv_pm1;
            % Linear constraints?? 
            % Newton method.. this part should be initialized
            %phi = rhs - ysum + sign(lambda)*sum(term); % need this == 0
            psi=abs(rhs-ysum)-sum((den.*r).^(pi));
            %else % Newton update step
                %dphi = sum(inv_pm1.*term)/abs(lambda);
                dpsi=sum(pi.*den.*(r.^(-pi-1)));
                dr = psi/dpsi;
                r=r-dr;
                % restore lambda
                lambda = -sign(p(M).*a(M))*sign(rhs-ysum).*r.^(sign(p(M)-1));
                 
                %Not sure about this part.
                undone = abs(dpsi)>=1e-10*psi...
                & abs(psi)>=1e-10*phi_range;
            %end
        end
        x = subSolverRoutine(lambda,M);
        status = 0;
    end

end % modified ver of projransimp
