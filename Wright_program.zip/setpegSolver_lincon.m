function pegSolve=setpegSolver_lincon(obj,lincon,domain)
% Creates a solver routine pegSolve for the Lagrange multiplier subproblem:
%      "Given c and I, find rho and x such that
%         f1(x)+rho*lincon=0 and sum(lincon.*x)==c,"
% where [f,f1,f2]=obj(x,I).  The solver will be callable for a scalar c and
% index array I as  x = pegSolve(I,c)  to return a vector x with one entry
% for each i in I.  The index array I can be numerical or logical.  [How
% are endpoints of the domain of x(i) handled?]
%
% Interpretation: f1 is derivative of f, and f2 is derivative of f1.
% The value of f isn't needed.
%
% The input argument domain is a structure with fields describing an
% interval for the common domain of obj and con as follows:
%   lo is the lower endpoint (possibly -inf);
%   up is the upper endpoint (possibly inf);
%   lo_excl is true iff lo is excluded from the interval;
%   up_excl is true iff up is excluded from the interval.
% Each of these fields is an array of the full length of x.

% define parameters and allocate space for all runs
initlo = nan(size(domain.lo));
xx = zeros(size(initlo));
rho = 1; % ?
iters =0;

% prep the return argument
pegSolve = @pegSolveRoutine;

    function [x,status]=pegSolveRoutine(I,c,timeout)
        if all(isnan(initlo))
            [initlo,initup] = initinterval(domain);
            xx = (initlo+initup)/2;
        end
        [xx(I),rho,iters,status] = ...
            subprob_nmjointArmijo_lincon(...
            obj,lincon,domain,c,I,...
            xx(I),rho,iters,timeout);
        x = xx(I);
    end

end % setpegSolver

function [lo,up] = initinterval(domain)
% Provides an initial interval for each coordinate, based on its domain.
% Intended for use in setsubSolver.m and setpegSolver.m.
lo = zeros(size(domain.lo));
up = zeros(size(lo));
for i=1:numel(lo)
        a = domain.lo(i);
        b = domain.up(i);
        if isinf(b)
            if isinf(a) % (-inf,inf)
                lo(i) = -1;
                up(i) = 1;
            else
                up(i) = 2*abs(a)+1;
                if domain.lo_excl(i) % (a,inf)
                    lo(i) = a+(up(i)-a)/2;
                else % [a,inf)
                    lo(i) = a;
                end
            end
        elseif isinf(a)
            lo(i) = -2*abs(b)-1;
            if domain.up_excl(i) % (-inf,b)
                up(i) = b+(lo(i)-b)/2;
            else % (-inf,b]
                up(i) = b;
            end
        elseif domain.lo_excl(i)
            if domain.up_excl(i) % (a,b)
                lo(i) = a+(b-a)*.25;
                up(i) = a+(b-a)*.75;
            else % (a,b]
                lo(i) = a+(b-a)/2;
                up(i) = b;
            end
        else
            lo(i) = a;
            if domain.up_excl(i) % [a,b)
                up(i) = a+(b-a)/2;
            else % [a,b]
                up(i) = b;
            end
        end
end
end % function initinterval