function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    f(dim,internal)
% F instance function

p=unifrnd(0,1,dim,1);
p=sort(p); %Parameter P_i should be increasing value
%Lower bound and upper bound for the domains

lo=zeros(dim,1);
up=ones(dim,1);
%
arhs=cumsum(unifrnd(0,1,dim,1));

% function handles
obj=@objective;
lincon=ones(size(up));
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

% no closed-form solvers, but a special numerical subSolve is available
if nargin<2||internal
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
    %interSolve = setinterSolver_lincon(@objective,lincon,dom,...
    %    @subSolverRoutine);
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        xh = 1-x;
        f = (1/4)*xh.^4 + p(index).*xh;
        if nargout > 1
            f1 = -xh.^3 - p(index);
            if nargout > 2
                f2 = 3*xh.^2;
            end
        end
    end % objective

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    function [x,status]=subSolverRoutine(lambda,I,~)
        % minimize sum(obj(x)+lambda*con(x)) over x
        x = 1-(lambda-p(I)).^(1/3);
        status = 0;
    end

    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,M,rhs,timeout)
        if islogical(M)
            Msize = nnz(M);
        else
            Msize = length(M);
        end
        phi_range = sum((lambda_up-p(M)).^(1/3))...
            -sum((lambda_lo-p(M)).^(1/3));
        lambda = lambda_lo+.01*(lambda_up-lambda_lo);
        undone = abs(lambda_up-lambda_lo)>1e-10 & phi_range>1e-10;
        iters = 0;
        while undone 
            iters = iters+1;
            if mod(iters,100)==0&&timeout()
                status=2;
                return
            end
            term = (lambda-p(M)).^(1/3);
            phi = rhs - Msize + sum(term); % need this == 0
            if phi>1e-4*phi_range % step closer to lower endpoint
                lambda = lambda_lo+.01*(lambda-lambda_lo);
            else % use full Newton step
                dphi = sum(1./(term.*term))/3;
                dlambda = phi/dphi;
                lambda = lambda - dlambda;
                undone = abs(dlambda)>=1e-10*lambda ...
                    & abs(phi)>=1e-10*phi_range;
            end
        end
        x = subSolverRoutine(lambda,M);
        status = 0;
    end


end % f
