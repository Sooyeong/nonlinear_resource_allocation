function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    melman(dim,internal)
% problem data for Melman-Rabinowitz (they used dim=500:500:3000)

a = .001+(1000-.001)*rand(dim,1);
b = .001+(1000-.001)*rand(dim,1);
adivb = a./b;
inva = 1./a;
bdiva = b.*inva;
gamma = min(adivb); % upper bound for multiplier rho
xx = zeros(dim,1);
iters = 0;
xx(adivb>gamma) = subSolverRoutine(gamma,adivb>gamma,@(t)false);
K = sum(b.*xx); % infimum for rhs guaranteeing optimal 0<rho<gamma
rhs = 1.1*K; % raise K above its minimum poosible (M&R used 1.001*K)
  % [peg and breakpoint can't handle 1.01 or smaller, but
  %  ipm seems to have no trouble]
lo = zeros(dim,1); % formally excluded, but f has been extended
up = rhs./b; % formally infinite, but this very large bound is implied
  % [guarantees that g(lo)=0 <rhs< dim*rhs=g(up)]
arhs = cumsum(lo+b.*(up-lo).*rand(dim,1));

% function handles
obj = @objective;
lincon = b;
dom = struct(...
    'lo',zeros(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',false(dim,1),...
    'up_excl',true(dim,1));

% no closed-form solvers, but special subSolve available
if nargin<2||internal
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
%    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
%        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = @pegSolverRoutine;
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end
iters = 0;

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        I = x>0;
        invx = 1./x(I);
        eninvx = exp(-invx);
        f = -x; % important for x=0 (numerically helpful for x<0)
        f(I) = x(I).*(eninvx-1);
        f = f.*a(index);
        if nargout > 1
            f1 = -ones(size(x));
            f1(I) = (1+invx).*eninvx-1;
            f1 = f1.*a(index);
            if nargout>2
                f2 = zeros(size(x));
                f2(I) = eninvx .* invx.^3;
                f2 = f2.*a(index);
            end
        end
    end

    function [x,status] = subSolverRoutine(rho,I,timeout)
        % Minimize obj(x,I)+rho*con(x,I) over x in the domain.
%fprintf('SSR %d\n',iters)
        % First preallocate working space
        J = false(size(a));
        J(I) = true;
        q = zeros(size(a));
        invx = zeros(size(a));
        einvx = zeros(size(a));
        dx = zeros(size(a));
        
        % Solve (1+1/x)*exp(-1/x)-q==0 for x>0.
        q(J) = 1-rho.*bdiva(J);
        xx = zeros(size(a)); % Default is trivial case of q<=0, giving x=0.
        J(J) = q(J)>eps;
        % Apply Newton's method to nontrivial case, starting at inflection.
        xx(J) = 1/3;
        status = 0;
        %for nmstep=1:100
        nmsteps=0;
        while any(J)
            nmsteps=nmsteps+1;
            iters = iters+1;
            if mod(iters,100)==0&&timeout(), status=1; x=xx(I); return, end
            invx(J) = 1./xx(J);
            einvx(J) = exp(invx(J));
            dx(J) = (1+invx(J)-q(J).*einvx(J)) .* xx(J).^3;
            % keep only those indices where xx hasn't converged yet
            J(J) = abs(dx(J))>=1e-11*xx(J) & ...
               abs(q(J)-(1+invx(J))./einvx(J))>=1e-11*q(J);
            xx(J) = xx(J)-dx(J);
        end
        fprintf('nmsteps %d\n',nmsteps);
        if any(xx(I)<0)
            error('negative x-value created')
        end
        x = xx(I);
    end

    function [x,status] = subSolverRoutineY(lambda,I,timeout)
        % Minimize obj(x,I)+lambda*con(x,I) over x in the domain.
        J = false(size(a));
        J(I) = true;
        q = zeros(size(a));
        q(J) = 1-lambda./adivb(J);
        % We'll solve (1+y)*exp(-y)-q=0 for y>=0 and let x=1/y.
        y = inf(size(a)); % Default is trivial case of q<=0, giving x=0.
        % Apply Newton's method to nontrivial case.
        % [M&R: Halley's order-3 method (solve F=0 by NM on F/sqrt(F')=0).]
        J(J) = q(J)>0;
        y(J) = 1;
        y1 = zeros(size(a));
        expy = zeros(size(a));
        dy = zeros(size(a));
        status = 0;
        while any(J)
            iters = iters+1;
            if mod(iters,100)==0&&timeout(), status=1; x=1./y(I); return, end
            y1(J) = 1+y(J);
            expy(J) = exp(y(J));
            dy(J) = (y1(J)-q(J).*expy(J))./y(J);
            % keep only those indices where y hasn't converged yet
            J(J) = abs(dy(J))>=1e-11*y(J) & ...
                abs(q(J)-y1(J)./expy(J))>=1e-11*q(J);
            y(J) = y(J)+dy(J);
        end
        if any(y(I)<0)
            error('negative x-value created')
        end
        x = 1./y(I);
    end

    function [x,status] = subSolverRoutineINT(rho,I,timeout)
        % Minimize obj(x,I)+rho*con(x,I) over x in the domain.
%fprintf('SSRINT %d\n',iters)
        % First preallocate working space
        J = false(size(a));
        J(I) = true;
        q = zeros(size(a));
        invx = zeros(size(a));
        einvx = zeros(size(a));
        dx = zeros(size(a));
        
        % Solve (1+1/x)*exp(-1/x)-q==0 for x>0.
        q(J) = 1-rho.*bdiva(J);
        xx = zeros(size(a)); % Default is trivial case of q<=0, giving x=0.
        J(J) = q(J)>eps;
        % Apply Newton's method to nontrivial case, starting at inflection.
        xx(J) = 1/3;
        status = 0;
        while any(J)
            iters = iters+1;
            if mod(iters,100)==0&&timeout(), status=1; x=xx(I); return, end
            invx(J) = 1./xx(J);
            einvx(J) = exp(invx(J));
            dx(J) = (1+invx(J)-q(J).*einvx(J)) .* xx(J).^3;
            % keep only those indices where xx hasn't converged yet
            J(J) = abs(dx(J))>=1e-11*xx(J) & ...
                abs(q(J)-(1+invx(J))./einvx(J))>=1e-11*q(J);
            xx(J) = xx(J)-dx(J);
        end
        if any(xx(I)<0)
            error('negative x-value created')
        end
        x = xx(I);
    end

    function [x,status] = interSolverRoutine(rho_lo,rho_up,M,rhs,timeout)
        % Find the x that corresponds to rho having
        %     rhs==sum(b(M).*subSolve(rho,M)),   rho_lo<rho<rho_up.
        % Approach: multiply equation by 1-b(k)*rho, then apply Newton's
        % method initialized at the left endpoint rho_lo.
fprintf('ISR %d; %g, %g, %d\n',iters,rho_lo,rho_up,length(M))

        status =0;
        if length(M)==1
            % solution in closed form
            x = rhs/b(M);
            [~,f1] = objective(x,M);
            rho = -f1/b(M);
            if rho>rho_up || rho<rho_lo
                status = 1;
            end
            return
        end
if iters==1806% || iters==1081
THISISIT = true;
else
THISISIT = false;
end
        
        bk = max(bdiva(M));
        rho = rho_lo;
        [x,status] = subSolverRoutine(rho,M,timeout);
        if status, error('bad status 2'), end
        bx = b(M).*x;
        sumbx = sum(bx);
        res = (1-bk*rho)*(sumbx-rhs);

        if THISISIT
            rho_used = rho;
            res_used = res;
            %dres_used = zeros(0,1);
            %drho_used = zeros(0,1);
        end
        
        drho = inf; % no Newton step yet
        while res~=0 ... % did not find root exactly
                && abs(drho)>1e-10*abs(rho) % Newton step is large
            iters = iters+1;
            if mod(iters,100)==0&&timeout(), status=1; disp('bad status 3'), break, end
            
            dres = -bk*sumbx -(1-bk*rho)*sum(bx.*x.^2.*bdiva(M).*exp(1./x));
            drho = res/dres; % Newton step
            rho = rho - drho;
            
            if THISISIT
                %dres_used(end+1) = dres;
                %drho_used(end+1) = drho;
                rho_used(end+1) = rho;
            end
            
            if res~=0 && abs(drho)>1e-10*abs(rho) && (rho>rho_up || rho<rho_lo)
%                 x = subSolverRoutineINT(rho,M,timeout);
%                 bx = b(M).*x;
%                 sumbx = sum(bx);
%                 res = (1-bk*rho)*(sumbx-rhs);
%                 res_used(end+1) = res;
%                 rhospace=linspace(rho_lo,rho_up);
%                 for i=1:length(rhospace)
%                     [x,status] = subSolverRoutine(rhospace(i),M,timeout);
%                     if status, disp('bad status'), end
%                     bx = b(M).*x;
%                     sumbx = sum(bx);
%                     %res(i) = (sumbx-rhs);
%                     res(i) = (1-bk*rhospace(i))*(sumbx-rhs);
%                     %dres(i) = -bk*sumbx -(1-bk*rhospace(i))*sum(bx.*x.^2.*bdiva(M).*exp(1./x));
%                 end
                %close all
                %subplot(1,2,1)
                %plot(rhospace,res)
%                 hold on
%                 plot(rhospace,zeros(size(rhospace)),'k')
%                 for i=1:length(rho_used)
%                    plot(rho_used(i),res_used(i),'*')
%                    %pause
%                 end
                %subplot(1,2,2)
                %plot(rhospace(1:end-1),(diff(res)./diff(rhospace)),'r')
                %plot(rhospace(1:end-1),diff(res)./diff(rhospace),'r*',rhospace,dres,'b')
                %plot(rhospace,dres,'b')
%                 pause
                error('bad NM step')
            end
            iter0 = iters;
            [x,status] = subSolverRoutine(rho,M,timeout);
            %if THISISIT, disp(iters-iter0), end
            if status, disp('bad status 4'), break, end
            bx = b(M).*x;
            sumbx = sum(bx);
            res = (1-bk*rho)*(sumbx-rhs);
            if THISISIT
                res_used(end+1) = res;
            end
        end
        
        if THISISIT
            fprintf('%d NM steps\n',length(rho_used))
            rhospace=linspace(rho_lo,rho_up,5000);
            %rhospace=linspace(5.9199604155e-7,5.919960418e-7,5000);
            psi=zeros(size(rhospace));
            for i=1:length(rhospace)
                x = subSolverRoutine(rhospace(i),M,@(t)false);
                bx = b(M).*x;
                sumbx = sum(bx);
                phi(i) = (sumbx-rhs);
                psi(i) = (1-bk*rhospace(i))*(sumbx-rhs);
            end
            close all
            %plot(rhospace,phi,'b'), hold on, plot(rhospace,zeros(size(rhospace)),'k')
            plot(rhospace,psi,'b'), hold on, plot(rhospace,zeros(size(rhospace)),'k')
            for i=1:length(rho_used)
                plot(rho_used(i),res_used(i),'*')
                pause
            end
            error('that was it')
        end
    end

    function [x,status] = pegSolverRoutine(M,rhs,timeout)
        % starting guess from Melman & Rabinowitz
        rho = min(adivb(M))*sum(b(M).*subSolverRoutine(rhs/sum(b(M))));
        [x,status] = interSolverRoutine(rho,[],M,rhs,timeout);
    end


end % melman
