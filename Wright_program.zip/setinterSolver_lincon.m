function interSolve=setinterSolver_lincon(obj,lincon,dom,subSolve)
% Creates a solver routine interSolve for the Lagrange multiplier
% subproblem:
%      "Given c and I, find rho (between rholo and rhoup) and x such that
%         f1(x)+rho*lincon=0 and sum(lincon.*x)==c,"
% where [f,f1,f2]=obj(x,I).  The solver will be callable for a scalar c and
% index array I as
%       x = interSolve(rholo,rhoup,I,c)
% to return a vector x with one entry for each i in I.  The index array I
% can be numerical or logical.
%
% Interpretation: f1 is derivative of f, and f2 is derivative of f1.
% The value of f isn't needed.
%

% prep the return argument
interSolve = @interSolveRoutine;
iters = 0;


figure
plot(linspace(lambda_lo,lambda_up),...
rhs-Msize+sum((linspace(lambda_lo,lambda_up)-p(M)).^(1/3)))
hold on
plot([lambda_lo,lambda_up],[0,0])


    function [x,status]=interSolveRoutine(rholo,rhoup,I,c,timeout)
        rho = (rholo+rhoup)/2;
        [x,status] = subSolve(rho,I,timeout);
        if status, return, end
        [x,~,iters,status] = ...
            subprob_nmjointArmijo_lincon(...
            obj,lincon,dom,c,I,x,rho,iters,timeout);
    end

end % function setinterSolver


