function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    strat(dim,internal)
% Stratified Sampling problem data

d = 10000 + (20000-10000) .* rand(dim,1); % 10000 < d < 20000
b = 10 + (50-10) .* rand(dim,1); % 10 < b < 50
lo = 100 + (200-100) .* rand(dim,1); % 100 < lo < 200
up = lo + (200-lo) .* rand(dim,1); % 100 < up < 200 and lo < up
% choose arhs last to guarantee feasibility
arhs = cumsum(b.*lo + b.*(up-lo).*rand(dim,1));

% function handles
obj = @objective;
lincon = b;
dom = struct(...
    'lo',zeros(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

if nargin<2||internal
    subSolve = @subSolverRoutine;
    pegSolve = @pegSolverRoutine;
    interSolve = @interSolverRoutine;
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver_lincon(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        f = d(index) ./ x;
        if nargout > 1
            f1 = -f ./ x;
            if nargout>2
                f2 = -2*f1 ./ x;
            end
        end
    end

    function [xh,status] = subSolverRoutine(lambda,I,~)
        xh = sqrt(d(I)./(lambda*b(I)));
        status = 0;
    end
    function [x,status] = pegSolverRoutine(M,rhs,~)
        lambda_bottom = rhs;
        lambda_top = sum(sqrt(b(M).*d(M)));
        lambda = (lambda_top/lambda_bottom)^2;
        x = subSolverRoutine(lambda,M);
        status = 0;
    end
    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,M,rhs,~)
        lambda_bottom = rhs;
        lambda_top = sum(sqrt(b(M).*d(M)));
        lambda = (lambda_top/lambda_bottom)^2;
        lambda = max(lambda_lo,min(lambda,lambda_up));
        x = subSolverRoutine(lambda,M);
        status = 0;
    end
end % strat