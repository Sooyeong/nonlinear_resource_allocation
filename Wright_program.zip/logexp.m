function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    logexp(dim,~)
% problem data for:
%   obj = log-exponential with k terms
%   con = positive linear combination

k = 5;
a = randn(dim,k);
b = randn(dim,k);
c = 10*rand(dim,1);
up = 5*randn(dim,1); % any value, in principle
lo = up-.05*abs(up)-5*abs(randn(dim,1)); % any value lo < up
objlo = objective(lo);
objup = objective(up);
if any(abs(objlo-objup)<=1e-14*max(abs(objlo),abs(objup)))
    error('obj does not distinguish between lo and up')
end
% choose rhs last to guarantee feasibility
arhs = cumsum(c.*lo+c.*(up-lo).*rand(dim,1));

% function handles
obj = @objective;
lincon = c;
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

% specialized solvers
subSolve = @subSolverRoutine;
interSolve = @interSolverRoutine;
%subSolve = setsubSolver_lincon(@objective,lincon,lo,up);
%interSolve = setinterSolver_lincon(@objective,lincon,dom,...
%    setsubSolver_lincon(@objective,lincon,lo,up));
pegSolve = setpegSolver_lincon(obj,lincon,dom);
iters = 0;

% Pegging frequently fails because an unconstrained subproblem has no
% solution.  For example, in subSolve the derivative f1 has bounded range,
% so some values -rho*c yield unconstrained subproblems with solutions at
% x=+/-infinity.  Within the context of subSolve, we could simply assign
% x-values outside the problem bounds lo and up. But because pegSolve
% performs much of its work outside the controlled context of subSolve, it
% must either enforce a separate set of bounds (defeating the purpose of
% pegging and making it uncompetitive) or else detect the unboundedness
% and somehow peg accordingly.

% pre-allocate full-size arrays used in subSolverRoutine
xtmp = zeros(size(c));
E = zeros(size(a));
sumE = zeros(size(c));
sumaE = zeros(size(c));
suma2E = zeros(size(c));
res_x = zeros(size(c));
res_x_lo = zeros(size(c));
res_x_up = zeros(size(c));
dx = zeros(size(c));
x_lo = zeros(size(c));
x_up = zeros(size(c));
x_width = zeros(size(c));
lamc = zeros(size(c));
J = false(size(c));
JJ = false(size(c));

% enter_inter=0; % DEBUG - remove later

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        expaxb = exp( a(index,:).*x+b(index,:) );
        sumexp = sum(expaxb,2);
        f = log(sumexp);
        if nargout>1
            sumaexp = sum(a(index,:).*expaxb,2);
            f1 = sumaexp ./ sumexp;
            if nargout>2
                suma2exp = sum(a(index,:).^2.*expaxb,2);
                f2 = (suma2exp.*sumexp-sumaexp.^2) ./ sumexp.^2;
            end
        end
    end

    function [xh,status] = subSolverRoutine(lambda,I,timeout)
        status = 0;
        if ~any(I)
            xh = zeros(0,1);
            return
        else
            xh = nan(nnz(I),1);
        end
        lamc(I) = lambda*c(I);
        J(:) = false;
        J(I) = true; % J is the set of unfinished coordinates
        JJ = J; % maintain this copy of J to address subsets of J

        % Solve f1+lambda*c=0 with NM. (monotone; multiple inflections)
        %%% Note: f1 has bounded range - need to handle outside values?

        % starting bracket based on problem data
        x_lo(J) = lo(J);
        [~,f1_lo] = objective(x_lo(J),J);
        res_x_lo(J) = f1_lo+lamc(J);
        JJ(J) = res_x_lo(J)==0; % trivially solved
        xtmp(JJ) = x_lo(JJ);
        J(JJ) = false; JJ(JJ) = false; % these coordinates are finished
        JJ(J) = true; % reset JJ to match revised J
        
        x_up(J) = up(J);
        [~,f1_up] = objective(x_up(J),J);
        res_x_up(J) = f1_up+lamc(J);
        JJ(J) = res_x_up(J)==0; % trivially solved
        xtmp(JJ) = x_up(JJ);
        J(JJ) = false; JJ(JJ) = false; % these coordinates are finished
        JJ(J) = true; % reset JJ to match revised J
        
        % use midpoint as initial guess for the iterative search
        xtmp(J) = (x_lo(J)+x_up(J))/2;
        
        % check if residuals at bracket endpoints have same sign
        J(J) = (sign(res_x_lo(J))~=sign(res_x_up(J))); % trivially solved
        JJ(JJ) = J(JJ); % reduce JJ to match revised J
       
        % inline calculation of residual and its components
        E(J,:) = exp( a(J,:).*xtmp(J)+b(J,:) );
        sumE(J) = sum(E(J,:),2);
        sumaE(J) = sum(a(J,:).*E(J,:),2);
        res_x(J) = sumaE(J)+lamc(J).*sumE(J);
        
        % begin the iteration
        x_width(J) = x_up(J)-x_lo(J);
        dx(J) = inf;
        tol = 1e-10; % or 1e-11???
        inner_iter=0;
        while any(J) && inner_iter<20 % there are unfinished coordinates
            inner_iter=inner_iter+1;

            iters = iters+1;
            if mod(iters,100)==0&&timeout()
                status=21;
                return
            end
            
            % take Newton step
            suma2E(J) = sum(a(J,:).^2.*E(J,:),2);
            dx(J) = - res_x(J).*sumE(J) ./ (suma2E(J).*sumE(J)-sumaE(J).^2);
            xtmp(J) = xtmp(J)+dx(J);
           
            % bisect if Newton step escaped the bracket
            JJ(J) = xtmp(J)>x_up(J) | xtmp(J)<x_lo(J);
            dx(JJ) = inf; % discard Newton step
            xtmp(JJ) = (x_lo(JJ)+x_up(JJ))/2; % bisect as failsafe
            JJ(J) = true; % refill JJ to match J
            
            % calculate new residual
            E(J,:) = exp( a(J,:).*xtmp(J)+b(J,:) );
            sumE(J) = sum(E(J,:),2);
            sumaE(J) = sum(a(J,:).*E(J,:),2);
            res_x(J) = sumaE(J)+lamc(J).*sumE(J);
            
            % tighten bracket
            JJ(J) = sign(res_x_lo(J))==sign(res_x(J));
            x_lo(JJ) = xtmp(JJ);
            res_x_lo(JJ) = res_x(JJ);
            JJ(J) = sign(res_x_up(J))==sign(res_x(J));
            x_up(JJ) = xtmp(JJ);
            res_x_up(JJ) = res_x(JJ);
            JJ(J) = true; % refill JJ to match J
            
            % test termination criteria to identify unfinished coordinates
            J(J) = res_x(J)~=0 ... % not exact root
                & x_up(J)-x_lo(J)>tol*abs(x_width(J))... % wide bracket
                & abs(dx(J))>tol*max(1,abs(x_width(J))); % large Newton step
            JJ(JJ) = J(JJ); % reduce JJ to match revised J
        end
        xh = xtmp(I);
    end % subSolverRoutine

    function [x,status] = interSolverRoutine(rho_lo,rho_up,M,rhs,timeout)
        % Find x that corresponds to rho having
        %     rhs==sum(lincon(M).*subSolve(rho,M)),   rho_lo<rho<rho_up.
        % Approach: apply Newton's method with bisection failsafe.
        
        rho_width = rho_up-rho_lo;
        status = 0;
        tol = 1e-11;
        if length(M)==1
            % solution in closed form
            x = rhs/lincon(M);
            return
        end
        
        [x,status] = subSolve(rho_lo,M,timeout);
        if status
            return
        end
        res_rho_lo = sum(lincon(M).*x)-rhs;
        if res_rho_lo==0
            return
        end
        [x,status] = subSolve(rho_up,M,timeout);
        if status
            return
        end
        res_rho_up = sum(lincon(M).*x)-rhs;
        if res_rho_up==0
            return
        end

        rho = (rho_lo+rho_up)/2;
        if sign(res_rho_lo)==sign(res_rho_up)
            % numerically reached zero
            return
        end
        [x,status] = subSolve(rho,M,timeout);
        if status
            return
        end
        res_rho = sum(lincon(M).*x)-rhs;

        drho = inf; % no Newton step yet
        while res_rho~=0 ... % not exact root
                && rho_up-rho_lo>tol*max(abs(rho_lo),abs(rho_up))... % wide bracket
                && abs(drho)>tol*max(1,abs(rho_width)) % large Newton step
            [~,~,f2] = objective(x,M);
            dres_rho = -sum(lincon(M).^2./f2);
            drho = res_rho/dres_rho; % Newton step
            rho = rho - drho;
            
            if rho>rho_up || rho<rho_lo % Newton step escapes bracket
                drho = inf; % discard Newton step
                rho = (rho_lo+rho_up)/2; % bisect interval as failsafe
            end
            [x,status] = subSolve(rho,M,timeout);
            if status
                return
            end
            res_rho = sum(lincon(M).*x)-rhs;
            
            % tighten bracket
            if sign(res_rho_lo)==sign(res_rho)
                rho_lo = rho;
                res_rho_lo = res_rho;
            elseif sign(res_rho_up)==sign(res_rho)
                rho_up = rho;
                res_rho_up = res_rho;
            end
        end
    end % interSolverRoutine

end % logexp

