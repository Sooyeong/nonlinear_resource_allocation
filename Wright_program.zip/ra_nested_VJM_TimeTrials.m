function ra_nested_VJM_TimeTrials
% time trials for VJM on nested resource allocation problems

n_list = 100;
m_list = @(n)100;%... % these values cannot exceed n
%sort([logspace(0,round(log10(n)),round(log10(n))+1),round(n/2)]);
% 1,10,...,n/10 and n/2 and n

nsample = 100; % how many instances to generate
ntrials = 1; % how many times to solve each instance
maxtime = 30; % in seconds

problem_list = 2; % work through all of [4,7:11,15], one by one
problems = {
    @logexp  %1 - general subproblem solvers
    @(d,i)mixedpower(d,3,i) %2 - mixed power
    @quartic %3 - specialized subproblem solvers
    @bitranm     %4 - breakpoint in closed form
    @crashing    %5 - breakpoint in closed form
    @everett     %6 - breakpoint in closed form
    @f           %7 - breakpoint in closed form
    @projransimp %8 - breakpoint in closed form
    @fuelopt %9 - variable-fixing in closed form
    @strat   %10 - variable-fixing in closed form
    @(d,i)qknapsack(d,1,i) %11 - variable-fixing in closed form
    @(d,i)qknapsack(d,2,i) %12 - variable-fixing in closed form
    @(d,i)qknapsack(d,3,i) %13 - variable-fixing in closed form
    @(d,i)qknapsack(d,4,i) %14 - variable-fixing in closed form
    @(d,i)projsimplex(d,2,i)   %15 - variable-fixing in closed form
    @(d,i)projsimplex(d,2.5,i) %16 - variable-fixing in closed form
    @(d,i)projsimplex(d,3,i)   %17 - variable-fixing in closed form
    @(d,i)projsimplex(d,4,i)   %18 - variable-fixing in closed form
    };

% check n_list and m_list for correctness
if ~ismatrix(n_list) || isempty(n_list) || size(n_list,1)>1 || ...
        any(n_list~=round(n_list)) || any(n_list<0)
    disp(n_list)
    error('n_list must be a nonempty row vector of positive integers')
end
for n=n_list
    ML = m_list(n);
    if ~ismatrix(ML) || isempty(ML) || size(ML,1)>1 || ...
            any(ML~=round(ML)) || any(ML<0) || any(ML>n)
        disp(n)
        disp(ML)
        error('m_list must return a nonempty row vector of positive integers')
    end
end

for problem=problem_list
    
    % run small instance first to compile problem definition code
    rng default
    timeit(problems{problem},10,5,1,[],inf);
    
    for n=n_list
        for m=m_list(n)
            group = floor(n/m); % # of variables in 1st constraint
            
            rng default
            for instance=1:nsample
                prefix = sprintf('%d,%d,%d,%d,''VJM''',...
                    problem,n,m,instance);
                timeit(problems{problem},n,group,ntrials,prefix,maxtime);
            end
            
        end
    end
    
end

end

function timeit(problem,n,group,ntrials,prefix,maxtime)
% create problem instance and solve it
% Note: doing this inside a function lets Matlab handle allocation and
% trash collection over multiple instances, problems and sizes.

% indicate how to space constraints
aindex = (group:group:n-1)'; % uniformly spaced constraints
%aindex = sort(randperm(n-1,m-1))'; % randomly spaced constraints

internal = true;
num_infeasible = 0;
while true
    [obj,weight,arhs_full,lo,up,subSolve,interSolve] = ...
        problem(n,internal);
    arhs = arhs_full(aindex);
    eqrhs = arhs_full(end);
    if is_feasible(aindex,arhs,eqrhs,weight,lo,up), break, end
    num_infeasible = num_infeasible+1;
end

for trial=1:ntrials
    tic
    [x,status] = ra_nested_vjm3(obj,aindex,arhs,eqrhs,weight,lo,up,...
        subSolve,interSolve,...
        @()toc>maxtime);
    t = toc;
    if ~isempty(prefix)
[xIPM,~] = ra_nested_ipm(obj,aindex,arhs,eqrhs,weight,lo,up,@()toc>inf);
fprintf('%e ;',max(abs(x-xIPM)./(sqrt(eps)+abs(xIPM))))
        fprintf('%s,%d,%g,%d,%d\n',prefix,trial,t,status,num_infeasible);
    end
end

end