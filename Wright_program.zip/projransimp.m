function [obj,lincon,arhs,lo,up,subSolve,interSolve,pegSolve] = ...
    projransimp(dim,internal)
% problem data for:
%   obj = weighted sum of powers of absolute differences
%   con = sum of coordinates (simplex)

% create coordinate-level data
p = 2+2*rand(dim,1); % p>2
y = randn(dim,1).^2; % vector being projected
a = 1 + 4*rand(dim,1); % 1 < a < 5
lo = 1.5 * y.*rand(dim,1); % 0 < lo < 5
up = lo + (3*y-lo) .* rand(dim,1); % lo < up < 5
% choose rhs last to guarantee feasibility: con(lo) < rhs < con(up)
lincon = ones(size(up));
arhs = cumsum(lo + (up-lo).*rand(dim,1));

% function handles
obj = @objective;
dom = struct(...
    'lo',-inf(dim,1),...
    'up',inf(dim,1),...
    'lo_excl',true(dim,1),...
    'up_excl',true(dim,1));

% closed-form subSolve, but not pegSolve or interSolve
if nargin<2||internal
    subSolve = @subSolverRoutine;
    interSolve = @interSolverRoutine;
    %interSolve = setinterSolver_lincon(@objective,lincon,dom,...
    %    @subSolverRoutine);
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
else
    subSolve=setsubSolver_lincon(@objective,lincon,lo,up);
    interSolve = setinterSolver_lincon(@objective,lincon,dom,...
        setsubSolver(@objective,lincon,lo,up));
    pegSolve = setpegSolver_lincon(@objective,lincon,dom);
end

% function definitions
    function [f,f1,f2] = objective(x,index)
        if nargin == 1
            index = true(size(x));
        end
        xmy = x-y(index);
        axy = abs(xmy);
        if nargout==1
            f = a(index).*axy.^p(index);
        elseif nargout==2
            f1 = p(index).*a(index).*xmy.*axy.^(p(index)-2);
            f = f1.*xmy./p(index);
        else
            f2 = p(index).*(p(index)-1).*a(index).*axy.^(p(index)-2);
            f1 = f2.*xmy./(p(index)-1);
            f = f1.*xmy./p(index);
        end
    end

    function [xh,status] = subSolverRoutine(lambda,I,~)
        ratio = (lambda./p(I))./a(I);
        xh = y(I)-sign(ratio).*abs(ratio).^(1./(p(I)-1));
        status = 0;
    end

    function [x,status] = interSolverRoutine(lambda_lo,lambda_up,M,rhs,timeout)
        inv_ap = 1./(a(M).*p(M));
        inv_pm1= 1./(p(M)-1);
        den = inv_ap.^inv_pm1;
        ysum = sum(y(M));
        phi_range = sum(den.*(sign(lambda_up)*abs(lambda_up).^inv_pm1 ...
            - sign(lambda_lo)*abs(lambda_lo).^inv_pm1));
        if lambda_lo>0
            lambda = lambda_lo;
        elseif lambda_up<0
            lambda = lambda_up;
        elseif lambda_lo==0
            lambda = lambda_lo+.01*(lambda_up-lambda_lo);
        else
            lambda = lambda_up+.01*(lambda_lo-lambda_up);
        end
        undone = abs(lambda_up-lambda_lo)>1e-10 & phi_range>1e-10;
        iters = 0;
        while undone 
            iters = iters+1;
            if mod(iters,100)==0&&timeout()
                status=2;
                return
            end
            term = den.*abs(lambda).^inv_pm1;
            phi = rhs - ysum + sign(lambda)*sum(term); % need this == 0
            %else % use full Newton step
                dphi = sum(inv_pm1.*term)/abs(lambda);
                dlambda = phi/dphi;
                lambda = lambda - dlambda;
                undone = abs(dlambda)>=1e-10*lambda ...
                    & abs(phi)>=1e-10*phi_range;
            %end
        end
        x = subSolverRoutine(lambda,M);
        status = 0;
    end

end % projransimp
