function [x,rho,iters,status] = ...
    subprob_nmjointArmijo_lincon(obj,lincon,dom,c,I,x,rho,iters,timeout)
% Solves the system [ obj'(x)+rho*lincon , sum(lincon.*x)-c ] == 0 by joint
% Newton iterations in x and rho, along with an Armijo linesearch.  The
% entries in x are restricted to those in the index array I.  Input values
% of x and rho are initial guesses.

tol = 1e-8;

[~,f1] = obj(x,I);
gres = c-sum(lincon.*x);
res = f1+rho*lincon;
nrm = norm(res)+abs(gres);
r = tol*(nrm+1);

status = 0;
while nrm>r
    iters = iters+1;
    if mod(iters,100)==0&&timeout(), status=1; return, end
    
    % Newton step calculated by Schur complement of rho v. x
    [~,~,f2] = obj(x,I);
    g1div = lincon./f2;
    drho = (gres+sum(g1div.*res))/sum(lincon.*g1div);
    dx = (res-drho*lincon)./f2;
    
    t = 1;
    %if drho>0, t = min(t,.99*rho/drho); end
    J = dx>0;
    if any(J), t = min(t,.99*min((x(J)-dom.lo(J))./dx(J))); end
    J = dx<0;
    if any(J), t = min(t,.99*min((x(J)-dom.up(J))./dx(J))); end
    
    while true
        iters = iters+1;
        if mod(iters,100)==0&&timeout(), status=1; return, end
    
        % Armijo backtracking
        rho_t = rho-t*drho;
        x_t = x-t*dx;
        [~,f1] = obj(x_t,I);
        gres = c-sum(lincon.*x_t);
        res = f1+rho_t*lincon;
        nrm_t = norm(res)+abs(gres);
        if nrm_t<(1-t*1e-4)*nrm
            rho = rho_t;
            x = x_t;
            nrm = nrm_t;
            break
        end
        t = t/2;
        
    end
    
end

end

